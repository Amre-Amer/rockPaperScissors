using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class MeshGraphMgr : MonoBehaviour
{
    public Mimic mimic;
    MeshFilter meshfilter;
    public int numRecords;
    public int numFields;
    public int numVertices;
    public List<float[]> data = new List<float[]>();
    public float cellSize;
    public float scaleZ;
    Mesh mesh;
    public int numInputs;
    //public int nRecordStopAve = 25;
    //Texture2D texture;
    int[] indexesTraining = new int[] { 7, 12, 17, 22 };
    float[] dataFieldsTrack;
    bool ynInsertAverageInputs = true;
    int numMemory;
    public HandMgr handRock;
    public HandMgr handPaper;
    public HandMgr handScissors;
    public bool ynPause;
    int nClassification;
    int cntFrames;
    [HideInInspector]
    public OVRSkeleton skeletonLive;
    List<Vector3[]> dataMeshPos = new List<Vector3[]>();
    int numFieldsMesh;
    int numRecordsMesh;
    Vector3[] dataRecordMeshPos;
    public GameObject cubePrefab;
    public TMP_Text textGraphValues;
    float[] dataFieldsAve;
    List<List<GameObject>> cubes = new List<List<GameObject>>();
    private void Awake()
    {
        numInputs = indexesTraining.Length;
        Debug.Log("numInputs:" + numInputs + "\n");
        numRecords = 2; 
        numFields = numInputs;
        InitCubesWithNulls();
        cellSize = .0475f;
        scaleZ = .001f;
        //CreateTexture();
        CreateDataRecords();
        //ShareIndexesTrainingWithHands();
    }

    void Update()
    {
        TrackHand();
        //ScrollRight();
        //Data2DataMesh();
        //MakeMesh();
        ScrollRightCubes();
        MakeCubeGraph();
        UpdateGraphValues();
        if (cntFrames == 0) DebugInfo();
        cntFrames++;
    }

    void InitCubesWithNulls()
    {
        cubePrefab.SetActive(true);
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            List<GameObject> cubesRecord = new List<GameObject>();
            for (int nField = 0; nField < numFields; nField++)
            {
                GameObject cube = Instantiate(cubePrefab, cubePrefab.transform.parent);
                cube.name = "cube:nRecord:" + nRecord + " nField:" + nField;
                cubesRecord.Add(cube);
            }
            cubes.Add(cubesRecord);
        }
        cubePrefab.SetActive(false);
    }

    void UpdateGraphValues()
    {
        string txt = "";
        textGraphValues.text = txt;
        string s = "";
        for(int n = 0; n < dataFieldsTrack.Length; n++)
        {
            float v = dataFieldsTrack[n];
            txt += s + v.ToString("F0") + "°";
            s = "\n\n";
        }
        textGraphValues.text = txt;
    }

    void ScrollRightCubes()
    {
        if (ynPause) return;
        ynInsertAverageInputs = true;
        if (ynInsertAverageInputs)
        {
            data.Insert(1, dataFieldsTrack);
            data.RemoveAt(data.Count - 1);
            OverwriteAveInputsInMesh(0);
        } else
        {
            data.Insert(0, dataFieldsTrack);
            data.RemoveAt(data.Count - 1);
        }
    }

    void OverwriteAveInputsInMesh(int nRecord)
    {
        dataFieldsAve = GetAveInputsForNClassification();
        for (int nField = 0; nField < numFields; nField++)
        {
            int nFieldAve = nField;
            float v;
            if (nFieldAve < dataFieldsAve.Length)
            {
                v = dataFieldsAve[nFieldAve];
            }
            else
            {
                v = 0;
            }
            v = handRock.NormalizeAngle(v);
            data[nRecord][nField] = v;
        }
    }

    void MakeCubeGraph()
    {
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            for (int nField = 0; nField < numFields; nField++)
            {
                AddModCube(nRecord, nField);
            }
        }
    }

    void AddModCube(int nRecord, int nField)
    {
        GameObject cube = cubes[nRecord][nField];
        float x = cubePrefab.transform.localPosition.x + nRecord * cellSize;
        float y = cubePrefab.transform.localPosition.y + nField * cellSize;
        float v = data[nRecord][nField] * scaleZ;
        float z = -v / 2;
        float sx = cellSize;
        float sy = cellSize;
        float sz = -v;
        cube.transform.localPosition = new Vector3(x, y, z);
        cube.transform.localEulerAngles = Vector3.zero;
        cube.transform.localScale = new Vector3(sx, sy, sz);
        if (nRecord == 0)
        {
            Color color = mimic.GetColorInfer();
            cube.GetComponent<Renderer>().material.color = color;
        }
    }

    void AddFirstRecordZero()
    {
        Vector3[] dataRecordMeshPos = new Vector3[numFieldsMesh];
        for (int n = 0; n < numFieldsMesh; n++)
        {
            float x = cellSize;
            float y = n * cellSize;
            if (n == numFieldsMesh - 1) y -= cellSize;
            dataRecordMeshPos[n] = new Vector3(x, y, 0);
        }
        dataMeshPos.Add(dataRecordMeshPos);
    }

    void AddLastRecordZero()
    {
        dataRecordMeshPos = new Vector3[numFieldsMesh];
        for (int n = 0; n < numFieldsMesh; n++)
        {
            float x = (numRecordsMesh - 1 - 1) * cellSize;
            float y = n * cellSize;
            if (n == 0) y = cellSize;
            dataRecordMeshPos[n] = new Vector3(x, y, 0);
        }
        dataMeshPos.Add(dataRecordMeshPos);
    }

    void Data2DataMesh()
    {
        dataMeshPos.Clear();
        numFieldsMesh = numFields + 2;
        numRecordsMesh = numRecords + 2;
        AddFirstRecordZero();
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            AddRecordNonZero(nRecord);
        }
        AddLastRecordZero();
    }

    void AddRecordNonZero(int nRecord)
    {
        dataRecordMeshPos = new Vector3[numFieldsMesh];
        AddFieldZeroFirst(nRecord);
        AddFieldZeroLast(nRecord);
        //bool ynDiv = false;
        for (int nField = 0; nField < numFields; nField++)
        {
            //AddFieldNonZero(nRecord, nField, ynDiv);
            AddFieldNonZero(nRecord, nField, false);
            //ynDiv = true;
        }
        dataMeshPos.Add(dataRecordMeshPos);
    }

    void AddFieldZeroFirst(int nRecord)
    {
        float x = (nRecord + 1) * cellSize;
        float y = cellSize;
        dataRecordMeshPos[0] = new Vector3(x, y, 0);
    }

    void AddFieldNonZero(int nRecord, int nField, bool ynDiv)
    {
        float v = data[nRecord][nField];
        float x = (nRecord + 1) * cellSize;
        float y = (nField + 1) * cellSize;
        //if (ynDiv && ynTest)
        //{
        //    y -= cellSize;
        //    v *= 2;
        //}
        float z = v * scaleZ;
        Vector3 pos = new(x, y, z);
        dataRecordMeshPos[nField + 1] = pos;
    }

    void AddFieldZeroLast(int nRecord)
    {
        float x = (nRecord + 1) * cellSize;
        float y = (numFieldsMesh - 1 - 1) * cellSize;
        dataRecordMeshPos[numFieldsMesh - 1] = new Vector3(x, y, 0);
    }

    void TrackHand()
    {
        if (ynPause) return;
        if (indexesTraining == null) return;
        dataFieldsTrack = new float[numFields];
        UpdateTrackHandLive();
    }

    void UpdateTrackHandLive()
    {
        //int span = numFields / numInputs;
        for (int n = 0; n < numInputs; n++)
        {
            int nb = indexesTraining[n];
            float vX;
            if (Application.isEditor)
            {
                //vX = Mathf.Cos(3 * cntFrames * Mathf.Deg2Rad);
                vX = Random.Range(70f, 120f);
                //vX = (n + 1) * 10; // - (cntFrames % 10 * .1f);
            }
            else
            {
                vX = skeletonLive.Bones[nb].Transform.localEulerAngles.x;
            }
            vX = handRock.NormalizeAngle(vX);
            dataFieldsTrack[n] = vX;
            //for (int s = 0; s < span; s++)
            //{
            //    int nnn = n * span + s;
            //    dataFieldsTrack[nnn] = vX;
            //}
        }
    }

    void DebugInfo()
    {
        Debug.Log("numInputs:" + numInputs + "\n");
        Debug.Log("numRecords:" + numRecords + "\n");
        Debug.Log("numFields:" + numFields + "\n");
        Debug.Log("cellSize:" + cellSize + "\n");
        Debug.Log("scaleZ:" + scaleZ + "\n");
        Debug.Log("numMemory(numRecords+1 x numFields+1):" + numMemory + "\n");
    }

    //void ShareIndexesTrainingWithHands()
    //{
    //    handRock.indexesTraining = indexesTraining;
    //    handPaper.indexesTraining = indexesTraining;
    //    handScissors.indexesTraining = indexesTraining;
    //}

    void ZeroOutTopAndBottom()
    {
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            data[nRecord][0] = 0;
            data[nRecord][numFields - 1] = 0;
        }
    }

    public float[] GetAveInputsForNClassification()
    {
        nClassification = mimic.nOutput;
        if (Application.isEditor) nClassification = mimic.nInferTest;
        HandMgr hand = GetHandForN(nClassification);
        return hand.GetAverageInputs();
    }

    HandMgr GetHandForN(int n)
    {
        HandMgr hand = null;
        if (n == 0) hand = handRock;
        if (n == 1) hand = handPaper;
        if (n == 2) hand = handScissors;
        return hand;
    }

    //void ScrollRight()
    //{
    //    if (ynPause) return;
    //    float[] dataFields;
    //    dataFields = dataFieldsTrack;
    //    if (ynInsertAverageInputs)
    //    {
    //        OverwriteAveInputsInMesh(dataFields);
    //    }
    //    else
    //    {
    //        data.Insert(0, dataFields);
    //    }
    //    data.RemoveAt(data.Count - 1);
    //}

    void CreateDataRecords()
    {
        data.Clear();
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            float[] dataFields = new float[numFields];
            for (int nField = 0; nField < numFields; nField++)
            {
                float z = Random.Range(70f, 120f);
                dataFields[nField] = z;
            }
            data.Add(dataFields);
        }
        Debug.Log("CreateDataRecords: numRecords:" + numRecords + " numFields:" + numFields + "\n");
    }

    public void MakeMesh()
    {
        int numRecordsMesh = dataMeshPos.Count;
        if (numRecordsMesh == 0) return;
        int numFieldsMesh = dataMeshPos[0].Length;
        if (numFieldsMesh == 0) return;
        numMemory = (numRecordsMesh + 1) * (numFieldsMesh + 1);
        if (!mesh)
        {
            meshfilter = GetComponent<MeshFilter>();
            mesh = new Mesh();
            meshfilter.mesh = mesh;
            Vector3 sca = transform.localScale;
            //sca.x *= -1;
            transform.localScale = sca;
            mesh.name = "Procedural Grid for MeshMaker";
            if (numMemory > 65535)
            {
                mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                mesh.name += " (32)";
            }
        }
        mesh.Clear();
        List<Vector3> vertices = new List<Vector3>();
        List<Vector2> uvs = new List<Vector2>();
        for (int nRecord = 0; nRecord < numRecordsMesh; nRecord++)
        {
            for (int nField = 0; nField < numFieldsMesh; nField++)
            {
                Vector3 pos = dataMeshPos[nRecord][nField];
                vertices.Add(pos);
                float xFraction = nRecord / (float)numRecordsMesh;
                float yFraction = nField / (float)numFieldsMesh;
                uvs.Add(new Vector2(xFraction, yFraction));
            }
        }
        List<int> triangles = new List<int>();
        for (int i = 0; i < numRecordsMesh - 1; i++)
        {
            for (int j = 0; j < numFieldsMesh - 1; j++)
            {
                // Define triangles for each square in the grid
                int topLeftIndex = (i * (numFieldsMesh)) + j;
                int topRightIndex = topLeftIndex + 1;
                int bottomLeftIndex = ((i + 1) * (numFieldsMesh)) + j;
                int bottomRightIndex = bottomLeftIndex + 1;

                // Add triangles in clockwise order
                triangles.Add(topLeftIndex);
                triangles.Add(bottomLeftIndex);
                triangles.Add(topRightIndex);

                triangles.Add(topRightIndex);
                triangles.Add(bottomLeftIndex);
                triangles.Add(bottomRightIndex);
            }
        }

        // 3. Apply Mesh Data to the Mesh object
        mesh.vertices = vertices.ToArray();
        mesh.uv = uvs.ToArray();
        mesh.triangles = triangles.ToArray();
        mesh.RecalculateNormals();
        mesh.RecalculateTangents();
        numVertices = mesh.vertices.Length;
    }

    //public void CreateTexture()
    //{
    //    if (numInputs == 0)
    //    {
    //        Debug.Log("numInputs = 0\n");
    //        return;
    //    }
    //    if (numFields == 0)
    //    {
    //        Debug.Log("numFields = 0\n");
    //        return;
    //    }
    //    Debug.Log("CreateTexture\n");
    //    int width = 1;
    //    if (ynInsertAverageInputs)
    //    {
    //        width = 1;
    //    }
    //    int height = numFields;
    //    texture = new Texture2D(width, height);
    //    texture.filterMode = FilterMode.Point;
    //    for (int x = 0; x < width; x++)
    //    {
    //        int span = height / numInputs;
    //        if (span <= 0) span = 1;
    //        for (int y = 0; y < height; y++)
    //        {
    //            Color color = Color.black;
    //            Color colorGreenLight = (Color.white + Color.green) / 2;
    //            int nRow = y / span;
    //            float fraction = width / (float)numRecords;
    //            int n = (int)(fraction * width);
    //            if (ynInsertAverageInputs && x <= n)
    //            {
    //                color = Color.magenta;
    //                //break;
    //            }
    //            else
    //            {
    //                switch (nRow % 2)
    //                {
    //                    case 0:
    //                        color = Color.white;
    //                        break;
    //                    case 1:
    //                        color = colorGreenLight;
    //                        break;
    //                }
    //            }
    //            texture.SetPixel(x, y, color);
    //        }
    //    }
    //    texture.Apply();
    //    GetComponent<MeshRenderer>().materials[0].mainTexture = texture;
    //    string filespec = Path.Combine(Application.persistentDataPath, "texture.png");
    //    //        Debug.Log("path:" + filespec + "\n");
    //    byte[] bytes = texture.EncodeToPNG();
    //    File.WriteAllBytes(filespec, bytes);
    //}
}

//public enum Gestures
//{
//    none,
//    rock,
//    paper,
//    scissor
//}
