using System.Collections.Generic;
using Oculus.Interaction;
using UnityEngine;

public class HandXRSimpleMgr : MonoBehaviour
{
    public ScoreDisplaysMgr2 scoreDisplaysMgr;
    public HandVisual handLeft;
    public HandVisual handRight;
    public HandVisual handLiveLeft;
    public HandVisual handLiveRight;
    public TextAsset textAssetRockThrow;
    public TextAsset textAssetPaperThrow;
    public TextAsset textAssetScissorsThrow;
    List<List<float>> dataHands = new();
    List<List<float>> dataHandsRock = new();
    List<List<float>> dataHandsPaper = new();
    List<List<float>> dataHandsScissors = new();
    List<List<float>> dataMorphSource = new();
    List<List<float>> dataMorphTarget = new();
    float timePlaybackStart;
    float morphStartTime;
    float delayScore;
    float morphFraction;
    float durationMorph;
    int frameCurrent;
    int nHandRoll;
    int nMorphSource;
    int nMorphTarget;
    int nOutput;
    bool ynPlayback;
    bool ynMorph;
    public GameObject xrRootLiveLeft;
    public GameObject xrRootLiveRight;
    GameObject xrRootLive;
    int[] indexesTraining = new int[] { 7, 12, 17, 22 };
    AudioSource audioSource;
    public AudioClip clipPing;
    public AudioClip clipYeah;
    public AudioClip clipBoo;
    public AudioClip clipBoing;
    public AudioClip clipTick;
    enum rpsType
    {
        rock,
        paper,
        scissor
    }

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        TextAssetToData(textAssetRockThrow, dataHandsRock);
        TextAssetToData(textAssetPaperThrow, dataHandsPaper);
        TextAssetToData(textAssetScissorsThrow, dataHandsScissors);
    }

    void Start()
    {
        delayScore = 3.25f;
        durationMorph = .5f;
        PlayGame();
    }

    void Update()
    {
        UpdatePlayback();
        UpdateMorph();
    }

    void PlayGame()
    {
        if (dataMorphTarget.Count == 0)
        {
            dataMorphSource = GetRandomDataHands();
        }
        else
        {
            dataMorphSource = dataMorphTarget;
        }
        dataMorphTarget = GetRandomDataHands();
        float duration = GetDuration(dataMorphSource);
        scoreDisplaysMgr.ClearScores();
        PlaybackOnce(dataMorphSource);
        Invoke(nameof(ScoreAndShow), delayScore);
        Invoke(nameof(Morph), duration);
        Invoke(nameof(PlayGame), duration + durationMorph);
    }

    void Morph()
    {
        ynMorph = true;
        morphStartTime = Time.realtimeSinceStartup;
        //nMorphSource = dataMorphSource.Count - 1;
        //nMorphTarget = 0;
    }

    float GetDuration(List<List<float>> data)
    {
        if (data.Count == 0) return 0;
        float duration = data[data.Count - 1][0];
        return duration;
    }

    void PlaybackOnce(List<List<float>> data)
    {
        ynPlayback = true;
        dataHands = data;
        timePlaybackStart = Time.realtimeSinceStartup;
    }

    void UpdatePlayback()
    {
        if (!ynPlayback) return;
        bool ynFound = false;
        float timeTarget = Time.realtimeSinceStartup - timePlaybackStart;
        for (int nLine = 0; nLine < dataHands.Count; nLine++)
        {
            List<float> dataLine = dataHands[nLine];
            float elapsed = dataLine[0];
            if (timeTarget < elapsed)
            {
                DataToHands(dataHands, nLine);
                ynFound = true;
                break;
            }
        }
        if (!ynFound)
        {
            ynPlayback = false;
        }
    }

    void UpdateMorph()
    {
        if (!ynMorph) return;
        if (dataMorphSource.Count == 0 || dataMorphTarget.Count == 0) return;
        nMorphSource = dataMorphSource.Count - 1;
        nMorphTarget = 0;
        float elapsed = Time.realtimeSinceStartup - morphStartTime;
        for (int h = 0; h < 2; h++)
        {
            HandVisual hand = null;
            if (h == 0) hand = handLeft;
            if (h == 1) hand = handRight;
            if (elapsed >= durationMorph)
            {
                ynMorph = false;
                return;
            }
            morphFraction = elapsed / durationMorph;
            int count = hand.Joints.Count;
            for (int n = 0; n < count + 1; n++)
            {
                float posX = dataMorphSource[nMorphSource][1 + (h * 162) + n * 6 + 0];
                float posY = dataMorphSource[nMorphSource][1 + (h * 162) + n * 6 + 1];
                float posZ = dataMorphSource[nMorphSource][1 + (h * 162) + n * 6 + 2];
                float eulX = dataMorphSource[nMorphSource][1 + (h * 162) + n * 6 + 3];
                float eulY = dataMorphSource[nMorphSource][1 + (h * 162) + n * 6 + 4];
                float eulZ = dataMorphSource[nMorphSource][1 + (h * 162) + n * 6 + 5];
                Vector3 pos = new(posX, posY, posZ);
                Vector3 sourcePos = pos;
                Vector3 eul = new(eulX, eulY, eulZ);
                Quaternion sourceRotation = Quaternion.Euler(eul);
                posX = dataMorphTarget[nMorphTarget][1 + (h * 162) + n * 6 + 0];
                posY = dataMorphTarget[nMorphTarget][1 + (h * 162) + n * 6 + 1];
                posZ = dataMorphTarget[nMorphTarget][1 + (h * 162) + n * 6 + 2];
                eulX = dataMorphTarget[nMorphTarget][1 + (h * 162) + n * 6 + 3];
                eulY = dataMorphTarget[nMorphTarget][1 + (h * 162) + n * 6 + 4];
                eulZ = dataMorphTarget[nMorphTarget][1 + (h * 162) + n * 6 + 5];
                pos = new(posX, posY, posZ);
                Vector3 targetPos = pos;
                eul = new(eulX, eulY, eulZ);
                Quaternion targetRotation = Quaternion.Euler(eul);
                Quaternion interpolatedRotation = Quaternion.Slerp(sourceRotation, targetRotation, morphFraction);
                Vector3 interpolatedPosition = Vector3.Slerp(sourcePos, targetPos, morphFraction);
                if (n < count)
                {
                    hand.Joints[n].transform.localPosition = interpolatedPosition;
                    hand.Joints[n].transform.localRotation = interpolatedRotation;
                }
                else
                {
                    GameObject parentOrig = hand.transform.parent.gameObject;
                    hand.transform.SetParent(transform);
                    hand.transform.localPosition = interpolatedPosition;
                    hand.transform.localRotation = interpolatedRotation;
                    hand.transform.SetParent(parentOrig.transform);
                }
            }
        }
    }

    void TextAssetToData(TextAsset textAsset, List<List<float>> data)
    {
        string txtAll = textAsset.text;
        StringToDataHands(txtAll, data);
    }

    void PlayPing()
    {
        audioSource.PlayOneShot(clipPing);
    }

    public void PlayTick()
    {
        audioSource.PlayOneShot(clipTick);
    }

    public void PlayYeah()
    {
        audioSource.PlayOneShot(clipYeah);
    }

    public void PlayBoo()
    {
        audioSource.PlayOneShot(clipBoo);
    }

    public void PlayBoing()
    {
        audioSource.PlayOneShot(clipBoing);
    }

    public bool IsUsedForTraining(int n)
    {
        bool yn = false;
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            if (indexesTraining[i] == n)
            {
                yn = true;
                break;
            }
        }
        return yn;
    }

    public float NormalizeAngle(float vv)
    {
        float v = vv;
        if (v < -180) v += 360;
        if (v > 180) v -= 360;
        return v;
    }

    void StringToDataHands(string txtAll, List<List<float>> data)
    {
        data.Clear();
        string[] txtLines = txtAll.Split('\n');
        int nStart = 0;
        if (txtLines.Length > 0 && IsHeader(txtLines[0]))
        {
            nStart = 1;
        }
        for (int n = nStart; n < txtLines.Length; n++)
        {
            string[] txtRecord = txtLines[n].Split(',');
            List<float> dataRecord = new();
            for (int nn = 0; nn < txtRecord.Length; nn++)
            {
                float v = float.Parse(txtRecord[nn]);
                dataRecord.Add(v);
            }
            data.Add(dataRecord);
        }
    }

    public bool IsNumeric(string txt)
    {
        bool ynIsNumeric = false;
        if (float.TryParse(txt, out _))
        {
            ynIsNumeric = true;
        }
        return ynIsNumeric;
    }

    bool IsHeader(string txtLine)
    {
        string txtFirst = txtLine.Split(',')[0];
        bool ynIsNumeric = IsNumeric(txtFirst);
        return !ynIsNumeric;
    }

    List<List<float>> GetRandomDataHands()
    {
        int n = Random.Range(0, 3);
        switch (n)
        {
            case 0:
                return dataHandsRock;
            case 1:
                return dataHandsPaper;
            case 2:
                return dataHandsScissors;
            default:
                return null;
        }
    }

    void ScoreAndShow()
    {
        PlayPing();
        ScoreThrow();
        scoreDisplaysMgr.ShowScoreDisplays();
    }

    void ScoreThrow()
    {
        int s = 0;
        if (nOutput == nHandRoll)
        {
            s = 0;
        }
        else
        {
            switch (nOutput)
            {
                case 0:
                    if (nHandRoll == 1) s = -1;
                    if (nHandRoll == 2) s = 1;
                    break;
                case 1:
                    if (nHandRoll == 2) s = -1;
                    if (nHandRoll == 0) s = 1;
                    break;
                case 2:
                    if (nHandRoll == 0) s = -1;
                    if (nHandRoll == 1) s = 1;
                    break;
            }
        }
        scoreDisplaysMgr.AddScore(s);
    }

    public void DataToHands(List<List<float>> data, int nRecord)
    {
        frameCurrent = nRecord;
        List<float> dataRecord = data[nRecord];
        HandVisual hand = null;
        for (int h = 0; h < 2; h++)
        {
            if (h == 0) hand = handLeft;
            if (h == 1) hand = handRight;
            int countJoints = hand.Joints.Count;
            for (int n = 0; n < countJoints; n++)
            {
                float xPosL = dataRecord[1 + (h * 162) + n * 6 + 0];
                float yPosL = dataRecord[1 + (h * 162) + n * 6 + 1];
                float zPosL = dataRecord[1 + (h * 162) + n * 6 + 2];
                Vector3 posL = new(xPosL, yPosL, zPosL);
                hand.Joints[n].transform.localPosition = posL;
                float xEulL = dataRecord[1 + (h * 162) + n * 6 + 3];
                float yEulL = dataRecord[1 + (h * 162) + n * 6 + 4];
                float zEulL = dataRecord[1 + (h * 162) + n * 6 + 5];
                Vector3 eulL = new(xEulL, yEulL, zEulL);
                hand.Joints[n].transform.localEulerAngles = eulL;
            }
            float xPos = dataRecord[1 + (h * 162) + countJoints * 6 + 0];
            float yPos = dataRecord[1 + (h * 162) + countJoints * 6 + 1];
            float zPos = dataRecord[1 + (h * 162) + countJoints * 6 + 2];
            Vector3 wristPosL = new(xPos, yPos, zPos);
            float xEul = dataRecord[1 + (h * 162) + countJoints * 6 + 3];
            float yEul = dataRecord[1 + (h * 162) + countJoints * 6 + 4];
            float zEul = dataRecord[1 + (h * 162) + countJoints * 6 + 5];
            Vector3 wristEulL = new(xEul, yEul, zEul);
            GameObject parentOrig = hand.transform.parent.gameObject;
            hand.transform.SetParent(transform);
            hand.transform.localPosition = wristPosL;
            hand.transform.localEulerAngles = wristEulL;
            hand.transform.SetParent(parentOrig.transform);
        }
    }
}
