using System.IO;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public class FileMgr : MonoBehaviour
{
    public HandXRMgr handXRMgr;
    public RpsUI rpsUI;
    TextAsset textAssetCurrent;
    public TextAsset textAssetRockGesture;
    public TextAsset textAssetRockThrow;
    public TextAsset textAssetPaperGesture;
    public TextAsset textAssetPaperThrow;
    public TextAsset textAssetScissorsGesture;
    public TextAsset textAssetScissorsThrow;
    public TextAsset textAssetScreensaverGesture;
    public TextAsset textAssetScreensaverThrow;
    public string filespec;
    public string filename;
    bool ynAsync = false;

    private void Awake()
    {
        StartCSVCopy();
        handXRMgr.LoadRepresentativeInputsRPS();
    }

    void Start()
    {
        LoadDataFromPersistentFile();
        handXRMgr.LoadDataHandsScreensaver();
    }

    public void StartCSVCopy()
    {
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._gesture);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._throw);

        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._gesture);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._throw);

        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._gesture);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._throw);

        CopyResourceCSVToPersistentDataPath(GestureType.screensaver, GestureThrowType._gesture);
        CopyResourceCSVToPersistentDataPath(GestureType.screensaver, GestureThrowType._throw);
    }

    void CopyResourceCSVToPersistentDataPath(GestureType gesture, GestureThrowType gestureThrow)
    {
        handXRMgr.SetCurrentParameters(gesture, gestureThrow);
        SetFilenameAndFilespec();
        SetTextAssetCurrent();
        SaveTextAssetCurrentToPersistentDataPath();
    }

    void SetTextAssetCurrent()
    {
        textAssetCurrent = null;
        if (handXRMgr.gestureCurrent == GestureType.rock)
        {
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._gesture)
            {
                textAssetCurrent = textAssetRockGesture;
            }
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._throw)
            {
                textAssetCurrent = textAssetRockThrow;
            }
        }
        if (handXRMgr.gestureCurrent == GestureType.paper)
        {
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._gesture)
            {
                textAssetCurrent = textAssetPaperGesture;
            }
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._throw)
            {
                textAssetCurrent = textAssetPaperThrow;
            }
        }
        if (handXRMgr.gestureCurrent == GestureType.scissors)
        {
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._gesture)
            {
                textAssetCurrent = textAssetScissorsGesture;
            }
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._throw)
            {
                textAssetCurrent = textAssetScissorsThrow;
            }
        }
        if (handXRMgr.gestureCurrent == GestureType.screensaver)
        {
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._gesture)
            {
                textAssetCurrent = textAssetScreensaverGesture;
            }
            if (handXRMgr.gestureThrowCurrent == GestureThrowType._throw)
            {
                textAssetCurrent = textAssetScreensaverThrow;
            }
        }
    }

    void SaveTextAssetCurrentToPersistentDataPath()
    {
        string txtLines = "";
        if (textAssetCurrent)
        {
            txtLines = textAssetCurrent.text + "";
        }
        SaveStringToPersistentFile(txtLines, false, false);
        Debug.Log("CSVtoPersistent:" + filespec + "\n");
    }

    public void SaveStringToPersistentFile(string txtLines, bool ynTrainingData, bool ynShowInfo)
    {
        if (ynTrainingData)
        {
            filename = "training_data.csv";
            filespec = Path.Combine(Application.persistentDataPath, filename);
        }
        else
        {
            SetFilenameAndFilespec();
        }
        if (ynAsync)
        {
            SaveStringToPersistentFileAsync(txtLines);
        }
        else
        {
            File.WriteAllText(filespec, txtLines); // blocks (bad user experience)
        }
        if (ynShowInfo) rpsUI.ShowFileInfo();
    }

    async void SaveStringToPersistentFileAsync(string txtLines)
    {
        await WriteToFileAsync(filespec, txtLines);
    }

    public void LoadDataFromPersistentFile()
    {
        SetFilenameAndFilespec();
        string txtAll = "";
        if (!File.Exists(filespec))
        {
            Debug.Log("File not found:" + filespec + "\n");
        }
        else
        {
            txtAll = File.ReadAllText(filespec) + ""; // turns null to "" (needed?)
        }
        handXRMgr.LoadDataFromString(txtAll);
        handXRMgr.timeStartPlayback = Time.realtimeSinceStartup;
    }

    public void SaveDataToPersistentFile()
    {
        SaveTrainingDataIfApplicable();
        string txtLines = handXRMgr.DataHandsToString();
        SaveStringToPersistentFile(txtLines, false, true);
        Debug.Log("Save:" + filespec + "\n");
    }

    void SaveTrainingDataIfApplicable()
    {
        if (handXRMgr.gestureCurrent == GestureType.screensaver) return;
        if (handXRMgr.gestureThrowCurrent == GestureThrowType._throw) return;
        string txtTrainingData = handXRMgr.GetTrainingData();
        SaveStringToPersistentFile(txtTrainingData, true, true);
    }

    public void SetFilenameAndFilespec()
    {
        filename = handXRMgr.gestureCurrent.ToString();
        filename += "_" + handXRMgr.gestureThrowCurrent.ToString().Replace("_", "");
        filename += ".csv";
        filespec = Path.Combine(Application.persistentDataPath, filename);
    }

    public static async Task WriteToFileAsync(string filePath, string text)
    {
        byte[] buffer = Encoding.Unicode.GetBytes(text);
        int offset = 0;
        const int Buffer_Size = 4096; // Example buffer size
        using (var fileStream = new FileStream(filePath, FileMode.Append, FileAccess.Write, FileShare.None, bufferSize: Buffer_Size, useAsync: true))
        {
            await fileStream.WriteAsync(buffer, offset, buffer.Length);
        }
    }

}
