using System.Collections.Generic;
using System.IO;
using UnityEngine;
using TMPro;

public class Mimic : MonoBehaviour
{
    public MeshGraphMgr meshGraphMgr;
    public NNMgr nnMgr;
    public OVRSkeleton skeletonLiveLeft;
    public OVRSkeleton skeletonLiveRight;
    OVRSkeleton skeletonLive;
    public OVRCustomSkeleton skeletonMimicLeft;
    public OVRCustomSkeleton skeletonMimicRight;
    public OVRCustomSkeleton skeletonDemoLeft;
    public OVRCustomSkeleton skeletonDemoRight;
    OVRCustomSkeleton skeletonMimic;
    int[] indexesTraining = new int[] { 7, 12, 17, 22 };
    public GameObject markerPrefab;
    List<GameObject> markers = new List<GameObject>();
    public Material matRed;
    public Material matGreen;
    public Material matBlue;
    public Material matWhite;
    public Material matOrig;
    public List<List<float>> inputsTest = new List<List<float>>();
    public List<float> outputs = new List<float>();
    public int nOutput;
    Material matInfer;
    Vector3 posLastLeft;
    Vector3 posLastRight;
    float distMinMovement;
    bool ynRecordStart;
    float timeRecordStart;
    float timePlaybackStart;
    float durationRecord;
    List<List<float>> data = new List<List<float>>();
    int cntRecordPrep;
    public GameObject iconRecord;
    public GameObject quadRecord;
    public GameObject quadPlayback;
    public GameObject quadGame;
    public GameObject quadRock;
    public GameObject quadPaper;
    public GameObject quadScissors;
    public GameObject quadGesture;
    public GameObject quadThrow;
    public GameObject quadLeft;
    public GameObject quadRight;
    public GameObject quadLoop;
    public GameObject world;
    public Material matWorld;
    public Material matWorldRock;
    public Material matWorldPaper;
    public Material matWorldScissors;
    public TextAsset textAssetRockGestureLeft;
    public TextAsset textAssetRockGestureRight;
    public TextAsset textAssetRockThrowLeft;
    public TextAsset textAssetRockThrowRight;
    public TextAsset textAssetPaperGestureLeft;
    public TextAsset textAssetPaperGestureRight;
    public TextAsset textAssetPaperThrowLeft;
    public TextAsset textAssetPaperThrowRight;
    public TextAsset textAssetScissorsGestureLeft;
    public TextAsset textAssetScissorsGestureRight;
    public TextAsset textAssetScissorsThrowLeft;
    public TextAsset textAssetScissorsThrowRight;
    string filename;
    string filespec;
    TextAsset textAssetCurrent;
    string parametersCurrent;
    bool ynFirstTime = true;
    public HandMgr handRockThrowLeft;
    public HandMgr handPaperThrowLeft;
    public HandMgr handScissorsThrowLeft;
    public HandMgr handRockThrowRight;
    public HandMgr handPaperThrowRight;
    public HandMgr handScissorsThrowRight;
    int nHandRoll;
    int nHandRollLast;
    public GameObject world180;
    public List<ScoreDisplayMgr> scoreDisplays;
    float durationScores = 2;
    float delayScore = 2.75f;
    float intervalStaggerScore = .1f;
    public List<int> scores = new List<int>();
    public AudioClip clipTick;
    public AudioClip clipYeah;
    public AudioClip clipBoo;
    public GameObject quadDark;
    int sumScore;
    public TMP_Text textFps;
    int cntFps;
    float minMoveAutoLR = .02f;
    float minMoveAutoFingersLR = 10;
    Vector3 posMoveLeftLast;
    Vector3 posMoveRightLast;
    float angMoveLeftFingersLast;
    float angMoveRightFingersLast;
    public int nInferTest;
    public GameObject handleInfo;
    public TMP_Text textInfo;
    public GameObject handleGraph;
    public GameObject gridPrefab;
    List<GameObject> grid = new List<GameObject>();
    bool ynLoop;
    float morphDuration = .5f;
    AudioSource audioSource;
    ModeType modeCurrent;
    GestureType gestureCurrent;
    GestureType gestureCurrentLast;
    GestureThrowType gestureThrowCurrent;
    GestureThrowType gestureThrowTypeCurrentLast;
    LeftRightType leftRightCurrent;
    LeftRightType leftRightCurrentLast;
    enum ModeType
    {
        none,
        record,
        playback,
        game
    }
    enum GestureType
    {
        rock,
        paper,
        scissors
    }
    enum GestureThrowType
    {
        _gesture,
        _throw
    }
    enum LeftRightType
    {
        left,
        right
    }
    private void Start()
    {
        Debug.Log("path:" + Application.persistentDataPath + "\n");
        if (!Application.isEditor)
        {
            OVRManager.display.RecenteredPose += () =>
            {
                UpdateWorldPosition();
            };
        }
        HideThrows();
        HideScoreDisplays();
        CopyResourceCSVToPersistentDataPathIfNew();
        LoadPreferences();
        AdjustGestureButtons();
        AdjustGestureThrowButtons();
        AdjustLeftRightButtons();
        quadRecord.SetActive(false);
        quadDark.SetActive(false);
        durationRecord = 5;
        distMinMovement = .025f * Time.deltaTime;
        audioSource = GetComponent<AudioSource>();
        CreateMarkers();
        AdjustLeftRight();
        PlayTick();
        WorldAnimate();
        TurnOnOffDemos(false);
        CreateGrid();
        //if (Application.isEditor) InvokeRepeating(nameof(GameStart), 3, 6);
        //if (Application.isEditor) InvokeRepeating(nameof(GameStop), 6, 6);
        InvokeRepeating(nameof(Fps), 1, 1);
        InvokeRepeating(nameof(AdjustTextTraining), .5f, 1);
        if (Application.isEditor) InvokeRepeating(nameof(TestInfer), 3, 3);
    }

    void TestInfer()
    {
        nInferTest++;
        if (nInferTest >= 3) nInferTest = 0;
    }

    void Update()
    {
        AutoDetectLeftRight();
        AutoDetectLeftRightFingers();
        UpdateWorldPosition();
        MimicEuls();
        AdjustLeftRight();
        UpdateMarkers();
        UpdateInfer();
        UpdateRecord();
        UpdatePlayback();
        UpdateMeshGraph();
        FollowHandles();
        gestureCurrentLast = gestureCurrent;
        gestureThrowTypeCurrentLast = gestureThrowCurrent;
        leftRightCurrentLast = leftRightCurrent;
        cntFps++;
    }

    public void LoopPressed()
    {
        ynLoop = !ynLoop;
        quadLoop.SetActive(ynLoop);
        if (modeCurrent != ModeType.playback)
        {
            PlayBackPressed();
        }
    }

    void CreateGrid()
    {
        gridPrefab.SetActive(true);
        float inch = .0254f;
        float delta = inch * 3;
        int numX = 9;
        int numY = 7;
        int numZ = 3;
        for(int nx = 0; nx < numX; nx++)
        {
            for (int ny = 0; ny < numY; ny++)
            {
                for (int nz = 0; nz < numZ; nz++)
                {
                    float x = (nx - (numX - 1) / 2f) * delta;
                    if (Mathf.Abs(x) > delta)
                    {
                        GameObject go = Instantiate(gridPrefab, gridPrefab.transform.parent);
                        float y = (ny - (numY + 1) / 2f) * delta;
                        float z = nz * delta;
                        Vector3 posL = new(x, y, z);
                        Vector3 pos = world.transform.TransformPoint(posL);
                        go.transform.position = pos;
                        grid.Add(go);
                    }
                }
            }
        }
        gridPrefab.SetActive(false);
    }

    void TurnOnOffGrid(bool yn)
    {
        gridPrefab.transform.parent.gameObject.SetActive(yn);
    }

    void FollowHandles()
    {
        textInfo.transform.position = handleInfo.transform.position;
        textInfo.transform.eulerAngles = handleInfo.transform.eulerAngles;
        meshGraphMgr.transform.position = handleGraph.transform.position;
        meshGraphMgr.transform.eulerAngles = handleGraph.transform.eulerAngles;
    }

    void AutoDetectLeftRight()
    {
        if (modeCurrent != ModeType.game) return;
        Vector3 posMoveLeft = skeletonLiveLeft.transform.position;
        Vector3 posMoveRight = skeletonLiveRight.transform.position;
        float distLeft = Vector3.Distance(posMoveLeft, posMoveLeftLast);
        float distRight = Vector3.Distance(posMoveRight, posMoveRightLast);
        if (distLeft > minMoveAutoLR)
        {
            if (leftRightCurrent != LeftRightType.left) LeftPressed();
            leftRightCurrent = LeftRightType.left;
        }
        if (distRight > minMoveAutoLR)
        {
            if (leftRightCurrent != LeftRightType.right) RightPressed();
            leftRightCurrent = LeftRightType.right;
        }
        posMoveLeftLast = posMoveLeft;
        posMoveRightLast = posMoveRight;
    }

    void AutoDetectLeftRightFingers()
    {
        if (Application.isEditor) return;
        if (modeCurrent != ModeType.game) return;
        int n = indexesTraining[0];
        float angMoveLeftFingers = skeletonLiveLeft.Bones[n].Transform.localEulerAngles.x;
        angMoveLeftFingers = NormalizeAngle(angMoveLeftFingers);
        float angMoveRightFingers = skeletonLiveRight.Bones[n].Transform.localEulerAngles.x;
        angMoveRightFingers = NormalizeAngle(angMoveRightFingers);
        float deltaLeftFingers = Mathf.Abs(angMoveLeftFingers - angMoveLeftFingersLast);
        float deltaRightFingers = Mathf.Abs(angMoveRightFingers - angMoveRightFingersLast);
        if (deltaLeftFingers > minMoveAutoFingersLR)
        {
            if (leftRightCurrent != LeftRightType.left) LeftPressed();
            leftRightCurrent = LeftRightType.left;
        }
        if (deltaRightFingers > minMoveAutoFingersLR)
        {
            if (leftRightCurrent != LeftRightType.right) RightPressed();
            leftRightCurrent = LeftRightType.right;
        }
        angMoveLeftFingersLast = angMoveLeftFingers;
        angMoveRightFingersLast = angMoveRightFingers;
    }

    void AdjustTextTraining()
    {
        if (modeCurrent == ModeType.game) return;
        string f1 = "<color=black>";
        string f2 = "<color=white>";
        string s = "\n";
        string txt = "<b>" + f2 + cntFps + f1 + "</b> fps me@amre-amer.com";
        txt += s + f1 + "deviceModel: <b>" + f2 + SystemInfo.deviceModel + "</b>";
        txt += s + f1 + "deviceName: <b>" + f2 + SystemInfo.deviceName + "</b>";
        txt += s + f1 + "deviceType: <b>" + f2 + SystemInfo.deviceType + "</b>";
        txt += s + f1 + "batteryLevel: <b>" + f2 + SystemInfo.batteryLevel + "</b>";
        txt += s + f1 + "processorCount: <b>" + f2 + SystemInfo.processorCount + "</b>";
        txt += s + f1 + "processorFrequency: <b>" + f2 + SystemInfo.processorFrequency + "</b>";
        txt += s + f1 + "processorManufacturer: <b>" + f2 + SystemInfo.processorManufacturer + "</b>";
        txt += s + f1 + "processorModel: <b>" + f2 + SystemInfo.processorModel + "</b>";
        txt += s + f1 + "processorType: <b>" + f2 + SystemInfo.processorType + "</b>";
        txt += s + f1 + "graphicsDeviceName: <b>" + f2 + SystemInfo.graphicsDeviceName + "</b>";
        txt += s + f1 + "graphicsMemorySize: <b>" + f2 + SystemInfo.graphicsMemorySize + "</b>";
        txt += s + f1 + "graphicsDeviceVendor: <b>" + f2 + SystemInfo.graphicsDeviceVendor + "</b>";
        txt += s + f1 + "System.GC.GetTotalMemory(true): <b>" + f2 + System.GC.GetTotalMemory(true).ToString("N0") + "</b>";
        textFps.text = txt;
        cntFps = 0;
    }

    void Fps()
    {
        string f1 = "<color=black>";
        string f2 = "<color=white>";
        string s = "\n";
        string txt = "<b>" + f2 + cntFps + f1 + "</b> fps";
        txt += s + f1 + "deviceModel: <b>" + f2 + SystemInfo.deviceModel + "</b>";
        txt += s + f1 + "deviceName: <b>" + f2 + SystemInfo.deviceName + "</b>";
        txt += s + f1 + "deviceType: <b>" + f2 + SystemInfo.deviceType + "</b>";
        txt += s + f1 + "batteryLevel: <b>" + f2 + SystemInfo.batteryLevel + "</b>";
        txt += s + f1 + "processorCount: <b>" + f2 + SystemInfo.processorCount + "</b>";
        txt += s + f1 + "processorFrequency: <b>" + f2 + SystemInfo.processorFrequency + "</b>";
        txt += s + f1 + "processorManufacturer: <b>" + f2 + SystemInfo.processorManufacturer + "</b>";
        txt += s + f1 + "processorModel: <b>" + f2 + SystemInfo.processorModel + "</b>";
        txt += s + f1 + "processorType: <b>" + f2 + SystemInfo.processorType + "</b>";
        txt += s + f1 + "graphicsDeviceName: <b>" + f2 + SystemInfo.graphicsDeviceName + "</b>";
        txt += s + f1 + "graphicsMemorySize: <b>" + f2 + SystemInfo.graphicsMemorySize + "</b>";
        txt += s + f1 + "graphicsDeviceVendor: <b>" + f2 + SystemInfo.graphicsDeviceVendor + "</b>";
        txt += s + f1 + "System.GC.GetTotalMemory(true): <b>" + f2 + System.GC.GetTotalMemory(true).ToString("N0") + "</b>";
        textFps.text = txt;
        cntFps = 0;
    }

    void StartShowScoreDisplay(ScoreDisplayMgr scoreDisplay, float delayStart)
    {
        scoreDisplay.gameObject.SetActive(true);
        scoreDisplay.StartScaleUpDelayed(delayStart);
    }

    void ShowScoreDisplays()
    {
        for (int n = 0; n < scores.Count; n++)
        {
            ScoreDisplayMgr scoreDisplay = scoreDisplays[n];
            int s = scores[n];
            Color color = GetColorForScore(s);
            SetScoreDisplayColor(scoreDisplay, color);
            float delayStart = n * intervalStaggerScore;
            StartShowScoreDisplay(scoreDisplay, delayStart);
        }
        for(int nn = scores.Count; nn < scoreDisplays.Count; nn++)
        {
            scoreDisplays[nn].gameObject.SetActive(false);
        }
        SetFinalScore();
        Invoke(nameof(HideScoreDisplays), durationScores);
    }

    void SetFinalScore()
    {
        sumScore = 0;
        for(int n = 0; n < scores.Count; n++)
        {
            sumScore += scores[n];
        }
        if (Mathf.Abs(sumScore) == 2)
        {
            if (sumScore == 2) audioSource.PlayOneShot(clipYeah);
            if (sumScore == -2) audioSource.PlayOneShot(clipBoo);
            scores.Clear();
        }
        if (scores.Count == 3)
        {
            if (sumScore > 0) audioSource.PlayOneShot(clipYeah);
            if (sumScore == 0) audioSource.PlayOneShot(clipTick);
            if (sumScore < 0) audioSource.PlayOneShot(clipBoo);
            scores.Clear();
        }
    }

    void PlayRoll()
    {
        nHandRoll = Random.Range(0, 3);
        Material mat = GetMatForIndex(nHandRoll);
        ShowClassificationWithHandsWithMat(nHandRoll, mat);
        float duration = GetThrowHandDuration(nHandRoll);
        MorphStart();
        Invoke(nameof(ThrowHand), morphDuration);
        Invoke(nameof(PlayRoll), morphDuration + duration + durationScores);
        Invoke(nameof(ScoreThrow), delayScore);
        Invoke(nameof(ShowScoreDisplays), duration);
        nHandRollLast = nHandRoll;
    }

    void MorphStart()
    {
        HandMgr handMorphSource = GetHandThrowForN(nHandRollLast);
        HandMgr handMorphTarget = GetHandThrowForN(nHandRoll);
        handMorphTarget.StartMorphEndToStart(handMorphSource, handMorphTarget, handMorphSource.data.Count - 1, 0, morphDuration);
    }

    void HideScoreDisplays()
    {
        for(int n = 0; n < scoreDisplays.Count; n++)
        {
            //scoreDisplays[n].TurnOnOffRenderer(false); // ScoreDisplayMgr updated, this line of code is old.
        }
    }

    Color GetColorForScore(int s)
    {
        Color color = Color.magenta;
        if (s == -1) color = Color.red;
        if (s == 0) color = Color.blue;
        if (s == 1) color = Color.green;
        return color;
    }

    void SetScoreDisplayColor(ScoreDisplayMgr scoreDisplay, Color color)
    {
        scoreDisplay.GetComponentInChildren<MeshRenderer>().material.color = color;
    }

    void ScoreThrow()
    {
        PlayTick();
        int s = 0;
        // 0 rock
        // 1 paper
        // 2 scissors
        // 0 < 1
        // 0 > 2
        // 1 > 0
        // 1 < 2
        // 2 < 0
        // 2 > 1
        if (nOutput == nHandRoll)
        {
            s = 0;
        } else
        {
            if (nOutput == 0)
            {
                if (nHandRoll == 1) s = -1;
                if (nHandRoll == 2) s = 1;
            }
            if (nOutput == 1)
            {
                if (nHandRoll == 0) s = 1;
                if (nHandRoll == 2) s = -1;
            }
            if (nOutput == 2)
            {
                if (nHandRoll == 0) s = -1;
                if (nHandRoll == 1) s = 1;
            }
        }
        Debug.Log("nOutput:" + nOutput + " nHandRoll:" + nHandRoll + " " + s + "\n");
        scores.Add(s);
    }

    //void AddRandomScore()
    //{
    //    int s = Random.Range(-1, 2);
    //    Debug.Log("Random score:" + s + "\n");
    //    scores.Add(s);
    //}

    Material GetMatForIndex(int n)
    {
        Material mat = null;
        if (n == 0) mat = matRed;
        if (n == 1) mat = matGreen;
        if (n == 2) mat = matBlue;
        return mat;
    }

    void ShowClassificationWithHandsWithMat(int n, Material mat)
    {
        ResetHandRenderers();
        HandMgr hand = GetHandThrowForN(n);
        hand.HighlightHandWithMat(mat);
    }

    void ResetHandRenderers()
    {
        handRockThrowLeft.ResetHandMaterial();
        handRockThrowRight.ResetHandMaterial();
        handPaperThrowLeft.ResetHandMaterial();
        handPaperThrowRight.ResetHandMaterial();
        handScissorsThrowLeft.ResetHandMaterial();
        handScissorsThrowRight.ResetHandMaterial();
    }

    HandMgr GetHandThrowForN(int n)
    {
        HandMgr hand = null;
        if (n == 0) hand = GetHandRockThrow();
        if (n == 1) hand = GetHandPaperThrow();
        if (n == 2) hand = GetHandScissorsThrow();
        return hand;
    }

    float GetThrowHandDuration(int n)
    {
        float duration = 0;
        switch (n)
        {
            case 0:
                duration = GetHandRockThrow().duration;
                break;
            case 1:
                duration = GetHandPaperThrow().duration;
                break;
            case 2:
                duration = GetHandScissorsThrow().duration;
                break;
        }
        return duration;
    }

    float ThrowHand()
    {
        float duration = 0;
        switch (nHandRoll)
        {
            case 0:
                HideThrows();
                GetHandRockThrow().gameObject.SetActive(true);
                GetHandRockThrow().StartLoopOnce();
                duration = GetHandRockThrow().duration;
                break;
            case 1:
                HideThrows();
                GetHandPaperThrow().gameObject.SetActive(true);
                GetHandPaperThrow().StartLoopOnce();
                duration = GetHandPaperThrow().duration;
                break;
            case 2:
                HideThrows();
                GetHandScissorsThrow().gameObject.SetActive(true);
                GetHandScissorsThrow().StartLoopOnce();
                duration = GetHandScissorsThrow().duration;
                break;
        }
        return duration;
    }

    HandMgr GetHandRockThrow()
    {
        if (leftRightCurrent == LeftRightType.left)
        {
            return handRockThrowLeft;
        } else
        {
            return handRockThrowRight;
        }
    }

    HandMgr GetHandPaperThrow()
    {
        if (leftRightCurrent == LeftRightType.left)
        {
            return handPaperThrowLeft;
        }
        else
        {
            return handPaperThrowRight;
        }
    }

    HandMgr GetHandScissorsThrow()
    {
        if (leftRightCurrent == LeftRightType.left)
        {
            return handScissorsThrowLeft;
        }
        else
        {
            return handScissorsThrowRight;
        }
    }

    void HideThrows()
    {
        handRockThrowLeft.gameObject.SetActive(false);
        handPaperThrowLeft.gameObject.SetActive(false);
        handScissorsThrowLeft.gameObject.SetActive(false);
        handRockThrowRight.gameObject.SetActive(false);
        handPaperThrowRight.gameObject.SetActive(false);
        handScissorsThrowRight.gameObject.SetActive(false);
    }

    public void HoverButton(GameObject quad)
    {
        quad.SetActive(true);
    }

    public void UnHoverButton(GameObject quad)
    {
        quad.SetActive(false);
    }

    void SetParametersCurrent()
    {
        parametersCurrent = gestureCurrent + "_" + gestureThrowCurrent + "_" + leftRightCurrent;
    }

    void SetParameters(GestureType gesture, GestureThrowType gestureThrow, LeftRightType leftRight)
    {
        if (gesture == GestureType.rock) gestureCurrent = GestureType.rock;
        if (gesture == GestureType.paper) gestureCurrent = GestureType.paper;
        if (gesture == GestureType.scissors) gestureCurrent = GestureType.scissors;
        if (gestureThrow == GestureThrowType._gesture) gestureThrowCurrent = GestureThrowType._gesture;
        if (gestureThrow == GestureThrowType._throw) gestureThrowCurrent = GestureThrowType._throw;
        if (leftRight == LeftRightType.left) leftRightCurrent = LeftRightType.left;
        if (leftRight == LeftRightType.right) leftRightCurrent = LeftRightType.right;
    }

    void SetTextAssetCurrent()
    {
        textAssetCurrent = null;
        if (gestureCurrent == GestureType.rock)
        {
            if (gestureThrowCurrent == GestureThrowType._gesture)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetRockGestureLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetRockGestureRight;
                }
            }
            if (gestureThrowCurrent == GestureThrowType._throw)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetRockThrowLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetRockThrowRight;
                }
            }
        }
        if (gestureCurrent == GestureType.paper)
        {
            if (gestureThrowCurrent == GestureThrowType._gesture)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetPaperGestureLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetPaperGestureRight;
                }
            }
            if (gestureThrowCurrent == GestureThrowType._throw)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetPaperThrowLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetPaperThrowRight;
                }
            }
        }
        if (gestureCurrent == GestureType.scissors)
        {
            if (gestureThrowCurrent == GestureThrowType._gesture)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetScissorsGestureLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetScissorsGestureRight;
                }
            }
            if (gestureThrowCurrent == GestureThrowType._throw)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetScissorsThrowLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetScissorsThrowRight;
                }
            }
        }
    }

    bool IsFirstTime()
    {
        bool yn = false;
        if (PlayerPrefs.GetString("first") == null) yn = true;
        return yn;
    }

    void CopyResourceCSVToPersistentDataPathIfNew()
    {
        if (IsFirstTime()) return;
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._gesture, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._gesture, LeftRightType.right);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._throw, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._throw, LeftRightType.right);

        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._gesture, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._gesture, LeftRightType.right);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._throw, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._throw, LeftRightType.right);

        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._gesture, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._gesture, LeftRightType.right);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._throw, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._throw, LeftRightType.right);

        PlayerPrefs.SetString("first", "YES");
        PlayerPrefs.Save();
    }

    void CopyResourceCSVToPersistentDataPath(GestureType gesture, GestureThrowType gestureThrow, LeftRightType leftRight)
    {
        SetParameters(gesture, gestureThrow, leftRight);
        SetFilenameAndFilespec();
        SetTextAssetCurrent();
        SaveResourceCSVtoPersistentDataPath();
    }

    void SaveResourceCSVtoPersistentDataPath()
    {
        File.WriteAllText(filespec, textAssetCurrent.text);
        Debug.Log("Save:" + filespec + "\n");
    }

    void UpdateWorldPosition()
    {
        float dist = Vector3.Distance(world.transform.position, Camera.main.transform.position);
        if (dist > .75f)
        {
            Vector3 pos = Camera.main.transform.TransformPoint(0, 0, .2f);
            world.transform.position = pos;
            world.transform.LookAt(Camera.main.transform.position);
            world.transform.Rotate(0, 180, 0);
            LevelEuler(world);
            PlayTick();
        }
    }

    void LevelEuler(GameObject go)
    {
        Vector3 eul = go.transform.localEulerAngles;
        eul.x = 0;
        eul.z = 0;
        go.transform.localEulerAngles = eul;
    }

    void TurnOnOffLeftRightSkeletons()
    {
        if (leftRightCurrent == LeftRightType.left)
        {
            skeletonDemoLeft.gameObject.SetActive(true);
            skeletonDemoRight.gameObject.SetActive(false);
        }
        else
        {
            skeletonDemoLeft.gameObject.SetActive(false);
            skeletonDemoRight.gameObject.SetActive(true);
        }
        if (modeCurrent != ModeType.playback)
        {
            skeletonDemoLeft.gameObject.SetActive(false);
            skeletonDemoRight.gameObject.SetActive(false);
            return;
        }
        if (leftRightCurrent == LeftRightType.left)
        {
            skeletonDemoLeft.gameObject.SetActive(true);
            skeletonDemoRight.gameObject.SetActive(false);
        }
        else
        {
            skeletonDemoLeft.gameObject.SetActive(false);
            skeletonDemoRight.gameObject.SetActive(true);
        }
    }

    void TurnOnOffDemos(bool yn)
    {
        if (yn)
        {
            TurnOnOffLeftRightSkeletons();
        }
        else
        {
            skeletonDemoLeft.gameObject.SetActive(false);
            skeletonDemoRight.gameObject.SetActive(false);
        }
    }

    void LoadPreferences()
    {
        string txt = PlayerPrefs.GetString("leftright");
        switch (txt)
        {
            case "left":
                leftRightCurrent = LeftRightType.left;
                break;
            case "right":
                leftRightCurrent = LeftRightType.right;
                break;
            default:
                leftRightCurrent = LeftRightType.left;
                break;
        }
        txt = PlayerPrefs.GetString("gestureThrow");
        switch (txt)
        {
            case "_gesture":
                gestureThrowCurrent = GestureThrowType._gesture;
                break;
            case "_throw":
                gestureThrowCurrent = GestureThrowType._throw;
                break;
            default:
                gestureThrowCurrent = GestureThrowType._gesture;
                break;
        }
        txt = PlayerPrefs.GetString("rockPaperScissors");
        switch (txt)
        {
            case "rock":
                gestureCurrent = GestureType.rock;
                break;
            case "paper":
                gestureCurrent = GestureType.paper;
                break;
            case "scissors":
                gestureCurrent = GestureType.scissors;
                break;
            default:
                gestureCurrent = GestureType.rock;
                break;
        }
    }

    void SavePreferences()
    {
        PlayerPrefs.SetString("leftRight", leftRightCurrent.ToString());
        PlayerPrefs.SetString("gestureThrow", gestureThrowCurrent.ToString());
        PlayerPrefs.SetString("rockPaperScissors", gestureCurrent.ToString());
        PlayerPrefs.Save();
    }

    void WorldAnimate()
    {
        int n = Random.Range(0, 4);
        Material mat = null;
        switch (n)
        {
            case 0:
                mat = matWorld;
                break;
            case 1:
                mat = matWorldRock;
                break;
            case 2:
                mat = matWorldPaper;
                break;
            case 3:
                mat = matWorldScissors;
                break;
        }
        world.GetComponent<MeshRenderer>().material = mat;
        Invoke(nameof(WorldAnimate), Random.Range(.1f, 1f));
    }

    void TestPlay()
    {
        ScissorsPressed();
        GesturePressed();
        LeftPressed();
        PlayBackPressed();
    }

    public void LeftPressed()
    {
        if (modeCurrent != ModeType.game) PlayTick();
        leftRightCurrent = LeftRightType.left;
        AdjustLeftRightButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
        TurnOnOffLeftRightSkeletons();
    }

    public void RightPressed()
    {
        if (modeCurrent != ModeType.game) PlayTick();
        leftRightCurrent = LeftRightType.right;
        AdjustLeftRightButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
        TurnOnOffLeftRightSkeletons();
    }

    void UpdateMeshGraph()
    {
        switch (leftRightCurrent)
        {
            case LeftRightType.left:
                meshGraphMgr.skeletonLive = skeletonLiveLeft;
                break;
            case LeftRightType.right:
                meshGraphMgr.skeletonLive = skeletonLiveRight;
                break;
        }
    }

    void AdjustLeftRightButtons()
    {
        switch (leftRightCurrent)
        {
            case LeftRightType.left:
                quadLeft.SetActive(true);
                quadRight.SetActive(false);
                break;
            case LeftRightType.right:
                quadLeft.SetActive(false);
                quadRight.SetActive(true);
                break;
        }
    }

    public void GesturePressed()
    {
        PlayTick();
        gestureThrowCurrent = GestureThrowType._gesture;
        AdjustGestureThrowButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
    }

    public void ThrowPressed()
    {
        PlayTick();
        gestureThrowCurrent = GestureThrowType._throw;
        AdjustGestureThrowButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
    }

    void AdjustGestureThrowButtons()
    {
        switch (gestureThrowCurrent)
        {
            case GestureThrowType._gesture:
                quadGesture.SetActive(true);
                quadThrow.SetActive(false);
                break;
            case GestureThrowType._throw:
                quadGesture.SetActive(false);
                quadThrow.SetActive(true);
                break;
        }
    }

    public void RockPressed()
    {
        PlayTick();
        gestureCurrent = GestureType.rock;
        AdjustGestureButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
    }

    void LoadPlayIfParametersChange()
    {
        if (modeCurrent != ModeType.playback) return;
        bool ynChange = false;
        if (gestureCurrentLast != gestureCurrent) ynChange = true;
        if (gestureThrowTypeCurrentLast != gestureThrowCurrent) ynChange = true;
        if (leftRightCurrentLast != leftRightCurrent) ynChange = true;
        if (ynChange)
        {
            LoadPlay();
        }
    }

    public void PaperPressed()
    {
        PlayTick();
        gestureCurrent = GestureType.paper;
        AdjustGestureButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
    }

    public void ScissorsPressed()
    {
        PlayTick();
        gestureCurrent = GestureType.scissors;
        AdjustGestureButtons();
        SavePreferences();
        LoadPlayIfParametersChange();
    }

    void AdjustGestureButtons()
    {
        switch (gestureCurrent)
        {
            case GestureType.rock:
                quadRock.SetActive(true);
                quadPaper.SetActive(false);
                quadScissors.SetActive(false);
                break;
            case GestureType.paper:
                quadRock.SetActive(false);
                quadPaper.SetActive(true);
                quadScissors.SetActive(false);
                break;
            case GestureType.scissors:
                quadRock.SetActive(false);
                quadPaper.SetActive(false);
                quadScissors.SetActive(true);
                break;
        }
    }

    void DataRecordToSkeleton(List<float>dataRecord, OVRSkeleton skeleton)
    {
        for (int n = 0; n < skeleton.Bones.Count; n++)
        {
            float x = dataRecord[1 + n * 3 + 0];
            float y = dataRecord[1 + n * 3 + 1];
            float z = dataRecord[1 + n * 3 + 2];
            Vector3 eulL = new Vector3(x, y, z);
            if (n == 7) Debug.Log("x:" + x.ToString("F2"));
            skeleton.Bones[n].Transform.localEulerAngles = eulL;
        }
        if (dataRecord.Count > skeleton.Bones.Count)
        {
            int nn = skeleton.Bones.Count;
            float x = dataRecord[1 + nn * 3 + 0];
            float y = dataRecord[1 + nn * 3 + 1];
            float z = dataRecord[1 + nn * 3 + 2];
            Vector3 pos = new (x, y, z);
            nn++;
            x = dataRecord[1 + nn * 3 + 0];
            y = dataRecord[1 + nn * 3 + 1];
            z = dataRecord[1 + nn * 3 + 2];
            Vector3 eul = new (x, y, z);
            skeleton.transform.localPosition = pos;
            skeleton.transform.localEulerAngles = eul;
        }
    }

    void UpdatePlayback()
    {
        if (modeCurrent != ModeType.playback) return;
        bool ynFound = false;
        float elapsedTarget = Time.realtimeSinceStartup - timePlaybackStart;
        for(int n = 0; n < data.Count; n++)
        {
            List<float> dataRecord = data[n];
            float elapsed = dataRecord[0];
            if (elapsed >= elapsedTarget)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    DataRecordToSkeleton(dataRecord, skeletonDemoLeft);
                }
                else
                {
                    DataRecordToSkeleton(dataRecord, skeletonDemoRight);
                }
                ynFound = true;
                break;
            }
        }
        if (!ynFound)
        {
            PlayTick();
            timePlaybackStart = Time.realtimeSinceStartup;
            if (ynLoop)
            {
                switch (gestureCurrent)
                {
                    case GestureType.rock:
                        PaperPressed();
                        break;
                    case GestureType.paper:
                        ScissorsPressed();
                        break;
                    case GestureType.scissors:
                        RockPressed();
                        break;
                }
            }
        }
    }

    void PlayStart()
    {
        Debug.Log("PlayStart\n");
        TurnOnOffDemos(true);
        modeCurrent = ModeType.playback;
        LoadPlay();
        timePlaybackStart = Time.realtimeSinceStartup;
        quadPlayback.SetActive(true);
    }

    void SkeletonToData(OVRSkeleton skeleton)
    {
        List<float> dataRecord = new List<float>()
        {
            Time.realtimeSinceStartup - timeRecordStart
        };
        for (int n = 0; n < skeleton.Bones.Count; n++)
        {
            Vector3 eulL = skeleton.Bones[n].Transform.localEulerAngles;
            dataRecord.Add(eulL.x);
            dataRecord.Add(eulL.y);
            dataRecord.Add(eulL.z);
        }
        GameObject parent = skeleton.transform.parent.gameObject;
        skeleton.transform.SetParent(world.transform);
        Vector3 posW = skeleton.transform.localPosition;
        Vector3 eulW = skeleton.transform.localEulerAngles;
        skeleton.transform.SetParent(parent.transform);
        dataRecord.Add(posW.x);
        dataRecord.Add(posW.y);
        dataRecord.Add(posW.z);
        dataRecord.Add(eulW.x);
        dataRecord.Add(eulW.y);
        dataRecord.Add(eulW.z);
        data.Add(dataRecord);
    }

    void UpdateRecord()
    {
        if (Application.isEditor) return;
        if (modeCurrent != ModeType.record) return;
        if (!ynRecordStart) return;
        SkeletonToData(skeletonLive);
    }

    public void RecordPressed()
    {
        PlayTick();
        if (modeCurrent == ModeType.record)
        {
            modeCurrent = ModeType.none;
        } else
        {
            modeCurrent = ModeType.record;
        }
        TurnOffRecordPlayGameQuads();
        if (modeCurrent == ModeType.record)
        {
            RecordStart();
        } else
        {
            RecordStop();
        }
        SavePreferences();
        TurnOnOffDemos(false);
        LoadPlayIfParametersChange();
    }

    public void PlayBackPressed()
    {
        PlayTick();
        if (modeCurrent == ModeType.playback)
        {
            modeCurrent = ModeType.none;
        }
        else
        {
            modeCurrent = ModeType.playback;
        }
        TurnOffRecordPlayGameQuads();
        if (modeCurrent == ModeType.playback)
        {
            PlayStart();
        }
        else
        {
            PlayStop();
        }
        SavePreferences();
        LoadPlayIfParametersChange();
    }

    public void GamePressed()
    {
        PlayTick();
        if (modeCurrent == ModeType.game)
        {
            modeCurrent = ModeType.none;
        }
        else
        {
            modeCurrent = ModeType.game;
        }
        TurnOffRecordPlayGameQuads();
        if (modeCurrent == ModeType.game)
        {
            GameStart();
        }
        else
        {
            GameStop();
        }
        SavePreferences();
        TurnOnOffDemos(false);
        LoadPlayIfParametersChange();
    }

    void TurnOffRecordPlayGameQuads()
    {
        quadRecord.SetActive(false);
        quadPlayback.SetActive(false);
        quadGame.SetActive(false);
        quadDark.SetActive(false);
    }

    void GameStart()
    {
        Debug.Log("GameStart\n");
        modeCurrent = ModeType.game;
        quadGame.SetActive(true);
        quadDark.SetActive(true);
        TurnOnOffGrid(false);
        RotateWorld180(); // ? still needed?
        scores.Clear();
        PlayRoll();
    }

    void GameStop()
    {
        Debug.Log("GameStop\n");
        modeCurrent = ModeType.none;
        quadGame.SetActive(false);
        quadDark.SetActive(false);
        TurnOnOffGrid(true);
        UnRotateWorld();
        CancelInvoke(nameof(PlayRoll));
        CancelInvoke(nameof(ScoreThrow));
        CancelInvoke(nameof(ShowScoreDisplays));
        HideThrows();
    }

    void RotateWorld180()
    {
        world180.transform.Rotate(0, 180, 0);
    }

    void UnRotateWorld()
    {
        world180.transform.Rotate(0, -180, 0);
    }

    void PlayStop()
    {
        Debug.Log("PlayStop\n");
        modeCurrent = ModeType.none;
        quadPlayback.SetActive(false);
        TurnOnOffDemos(false);
    }

    void RecordPrep()
    {
        iconRecord.GetComponent<MeshRenderer>().material.color = Color.red;
        if (cntRecordPrep < 6)
        {
            if (cntRecordPrep % 2 == 0) iconRecord.SetActive(true);
            if (cntRecordPrep % 2 == 1) iconRecord.SetActive(false);
            cntRecordPrep++;
            Invoke(nameof(RecordPrep), .5f);
        }
        else
        {
            iconRecord.SetActive(true);
            PlayTick();
            ynRecordStart = true;
            timeRecordStart = Time.realtimeSinceStartup;
            Invoke(nameof(RecordStopAndSave), durationRecord);
        }
    }

    void RecordStart()
    {
        Debug.Log("RecordStart\n");
        data.Clear();
        modeCurrent = ModeType.record;
        ynRecordStart = false;
        quadRecord.SetActive(true);
        cntRecordPrep = 0;
        RecordPrep();
    }

    void RecordStopAndSave()
    {
        RecordStop();
        SaveRecord();
    }

    void RecordStop()
    {
        Debug.Log("RecordStop\n");
        CancelInvoke(nameof(RecordPrep));
        CancelInvoke(nameof(RecordStopAndSave));
        iconRecord.SetActive(true);
        modeCurrent = ModeType.none;
        ynRecordStart = false;
        quadRecord.SetActive(false);
        iconRecord.GetComponent<MeshRenderer>().material.color = Color.grey;
    }

    void SetFilenameAndFilespec()
    {
        // example .../rock_throw_left.csv
        filename = gestureCurrent.ToString(); 
        filename += "_" + gestureThrowCurrent.ToString().Replace("_", "");
        filename += "_" + leftRightCurrent;
        filename += ".csv";
        filespec = Path.Combine(Application.persistentDataPath, filename);
    }

    void LoadPlay()
    {
        data.Clear();
        SetFilenameAndFilespec();
        string[] txtLines = File.ReadAllText(filespec).Split('\n');
        for (int n = 0; n < txtLines.Length; n++)
        {
            string[] txtRecord = txtLines[n].Split(',');
            List<float> dataRecord = new List<float>();
            for(int nn = 0; nn < txtRecord.Length; nn++)
            {
                float v = float.Parse(txtRecord[nn]);
                dataRecord.Add(v);
            }
            data.Add(dataRecord);
        }
    }

    void SaveRecord()
    {
        SetFilenameAndFilespec();
        string txtLines = "";
        string s = "";
        for(int n = 0; n < data.Count; n++)
        {
            List<float> dataRecord = data[n];
            string txtLine = "";
            string ss = "";
            for(int nn = 0; nn < dataRecord.Count; nn++)
            {
                float v = dataRecord[nn];
                txtLine += ss + v;
                ss = ",";
            }
            txtLines += s + txtLine;
            s = "\n";
        }
        File.WriteAllText(filespec, txtLines);
    }

    void MimicEuls() {
        MimicEul(skeletonLiveLeft, skeletonMimicLeft);
        MimicEul(skeletonLiveRight, skeletonMimicRight);
    }

    void UpdateInfer() {
        HandLiveToInferInputs();
        Infer();
        SetMatFromInferOutputs();
        SetMatSkeletonMimicInfer();
    }

    void SetMatSkeletonMimicInfer()
    {
        SetMatMimic(skeletonMimic, matInfer);
    }

    public Color GetColorInfer()
    {
        Color color = Color.black;
        if (nOutput == 0) color = Color.red;
        if (nOutput == 1) color = Color.green;
        if (nOutput == 2) color = Color.blue;
        return color;
    }

    void SetMatFromInferOutputs()
    {
        matInfer = null;
        if (nOutput == 0) matInfer = matRed;
        if (nOutput == 1) matInfer = matGreen;
        if (nOutput == 2) matInfer = matBlue;
    }

    void Infer() {
        float[] inputsTestArray = inputsTest[0].ToArray();
        float[] outputsArray = nnMgr.InferWithOutput(inputsTestArray);
        outputs = Array2List(outputsArray);
        nOutput = GetIndexOfMaxOutputs();
        if (Application.isEditor)
        {
            nOutput = nInferTest;
        }
    }

    void HandLiveToInferInputs()
    {
        inputsTest.Clear();
        List<float> inputsRecord = new List<float>();
        if (Application.isEditor)
        {
            inputsRecord = new List<float>() { 70, 70, 70, 70 };
        } else
        {
            for (int n = 0; n < skeletonLive.Bones.Count; n++)
            {
                OVRBone bone = skeletonLive.Bones[n];
                Vector3 eul = bone.Transform.localEulerAngles;
                if (IsUsedForTraining(n))
                {
                    float v = eul.x;
                    v = NormalizeAngle(v);
                    inputsRecord.Add(v);
                }
            }
        }
        inputsTest.Add(inputsRecord);
    }

    public float NormalizeAngle(float vv)
    {
        float v = vv;
        if (v < -180) v += 360;
        if (v > 180) v -= 360;
        return v;
    }

    public bool IsUsedForTraining(int n)
    {
        bool yn = false;
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            if (indexesTraining[i] == n)
            {
                yn = true;
                break;
            }
        }
        return yn;
    }

    int GetIndexOfMaxOutputs()
    {
        float maxV = -1;
        int maxN = -1;
        for (int n = 0; n < outputs.Count; n++)
        {
            float v = outputs[n];
            if (n == 0 || v > maxV)
            {
                maxV = v;
                maxN = n;
            }
        }
        return maxN;
    }

    List<float> Array2List(float[] array)
    {
        List<float> list = new List<float>();
        for (int n = 0; n < array.Length; n++)
        {
            list.Add(array[n]);
        }
        return list;
    }

    void AdjustLeftRight()
    {
        if (leftRightCurrent == LeftRightType.left)
        {
            skeletonLive = skeletonLiveLeft;
            skeletonMimic = skeletonMimicLeft;
            SetMatMimic(skeletonMimicLeft, matBlue);
            SetMatMimic(skeletonMimicRight, matOrig);
        }
        else
        {
            skeletonLive = skeletonLiveRight;
            skeletonMimic = skeletonMimicRight;
            SetMatMimic(skeletonMimicLeft, matOrig);
            SetMatMimic(skeletonMimicRight, matBlue);
        }
    }

    void CreateMarkers() {
        markerPrefab.SetActive(true);
        for (int n = 0; n < indexesTraining.Length; n++)
        {
            GameObject marker = Instantiate(markerPrefab, transform);
            marker.transform.localScale *= 2;
            markers.Add(marker);
        }
        markerPrefab.SetActive(false);
    }

    void MimicEul(OVRSkeleton skeletonLive, OVRCustomSkeleton skeletonMimic)
    {
        if (skeletonLive.Bones.Count == 0) return;
        for (int n = 0; n < skeletonLive.Bones.Count; n++)
        {
            Vector3 eulL = skeletonLive.Bones[n].Transform.localEulerAngles;
            skeletonMimic.Bones[n].Transform.localEulerAngles = eulL;
        }
        skeletonMimic.transform.eulerAngles = skeletonLive.Bones[1].Transform.eulerAngles;
    }

    void UpdateMarkers()
    {
        if (leftRightCurrent == LeftRightType.left)
        {
            UpdateMarkersForHand(skeletonLiveLeft);
        }
        else
        {
            UpdateMarkersForHand(skeletonLiveRight);
        }
    }

    void UpdateMarkersForHand(OVRSkeleton skeletonMimic)
    {
        if (skeletonMimic.Bones.Count == 0)
        {
            return;
        }
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            int n = indexesTraining[i];
            Vector3 pos = skeletonMimic.Bones[n].Transform.position;
            Vector3 eul = skeletonMimic.Bones[n].Transform.eulerAngles;
            markers[i].transform.position = pos;
            markers[i].transform.eulerAngles = eul;
        }
    }

    void SetMatMimic(OVRSkeleton skeletonMimic, Material mat)
    {
        skeletonMimic.GetComponentInChildren<SkinnedMeshRenderer>().material = mat;
    }

    public void SetMatLive(OVRSkeleton skeletonLive, Material mat)
    {
        skeletonLive.GetComponentInChildren<SkinnedMeshRenderer>().materials[0] = mat;
    }

    void PlayTick()
    {
        audioSource.PlayOneShot(clipTick);
    }
}
