using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GraphMgr : MonoBehaviour
{
    public RpsUI rpsUI;
    public HandXRMgr handXRMgr;
    public int numRecords;
    public int numFields;
    public int numVertices;
    public List<float[]> dataGraph = new List<float[]>();
    public float cellSize;
    public float scaleZ;
    public int numInputs;
    float[] dataInfer;
    public GameObject cubePrefab;
    public TMP_Text textGraphValues;
    float[] inputsInferAdd;
    float smooth = .1f;
    //public bool ynPause;

    List<List<GameObject>> cubes = new List<List<GameObject>>();
    private void Awake()
    {
        //ynPause = false;
        numInputs = handXRMgr.indexesTraining.Length;
        numRecords = 2; 
        numFields = numInputs;
        InitCubesWithNulls();
        cellSize = .0475f;
        scaleZ = .001f;
        CreateDataPlaceholder();
        inputsInferAdd = new float[handXRMgr.indexesTraining.Length];
    }

    private void Update()
    {
        float t = Time.realtimeSinceStartup;
        UpdateSmooth();
    }

    void UpdateSmooth()
    {
        //if (!ynPause) return;
        if (rpsUI.ynScreensaver) return;
        for (int n = 0; n < handXRMgr.indexesTraining.Length; n++)
        {
            dataGraph[0][n] = smooth * inputsInferAdd[n] + (1 - smooth) * dataGraph[0][n];
        }
    }

    public void UpdateGraph(float[] inputsInfer)
    {
        //if (!ynPause) return; 
        dataInfer = inputsInfer;
        //dataGraph[0] = handXRMgr.GetRepresentativeInputsForNOutput();
        inputsInferAdd = handXRMgr.GetRepresentativeInputsForNOutput();
        dataGraph[1] = dataInfer;
        MakeCubeGraph();
        UpdateGraphTextValues();
    }

    void InitCubesWithNulls()
    {
        cubePrefab.SetActive(true);
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            List<GameObject> cubesRecord = new List<GameObject>();
            for (int nField = 0; nField < numFields; nField++)
            {
                GameObject cube = Instantiate(cubePrefab, cubePrefab.transform.parent);
                cube.name = "cube:nRecord:" + nRecord + " nField:" + nField;
                cubesRecord.Add(cube);
            }
            cubes.Add(cubesRecord);
        }
        cubePrefab.SetActive(false);
    }

    void MakeCubeGraph()
    {
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            for (int nField = 0; nField < numFields; nField++)
            {
                AddModCube(nRecord, nField);
            }
        }
    }

    void AddModCube(int nRecord, int nField)
    {
        GameObject cube = cubes[nRecord][nField];
        float x = cubePrefab.transform.localPosition.x + nRecord * cellSize;
        float y = cubePrefab.transform.localPosition.y + nField * cellSize;
        float v = dataGraph[nRecord][nField] * scaleZ;
        float z = -v / 2;
        float sx = cellSize;
        float sy = cellSize;
        float sz = -v;
        if (Mathf.Abs(sz) < .01f)  sz = .01f;
        cube.name = "graph:x:" + x.ToString("F0") + ":y:" + y.ToString("F0") + ":v:" + dataGraph[nRecord][nField].ToString("F1");
        cube.transform.localPosition = new Vector3(x, y, z);
        cube.transform.localEulerAngles = Vector3.zero;
        cube.transform.localScale = new Vector3(sx, sy, sz);
        if (nRecord == 0)
        {
            Color color = GetColorForN(handXRMgr.nOutput);
            cube.GetComponentInChildren<Renderer>().material.color = color;
        }

    }

    public Color GetColorForN(int n)
    {
        Color color = Color.magenta;
        if (n == 0) color = Color.red;
        if (n == 1) color = Color.green;
        if (n == 2) color = Color.blue;
        return color;
    }

    void UpdateGraphTextValues()
    {
        string txt = "";
        string s = "";
        for (int n = dataInfer.Length - 1; n >= 0; n--)
        {
            float v = dataInfer[n];
            txt += s + v.ToString("F0") + "°";
            s = "\n\n";
        }
        textGraphValues.text = txt;
    }

    void CreateDataPlaceholder()
    {
        dataGraph.Clear();
        for (int nRecord = 0; nRecord < numRecords; nRecord++)
        {
            float[] dataFields = new float[numFields];
            for (int nField = 0; nField < numFields; nField++)
            {
                float z = Random.Range(70f, 120f);
                dataFields[nField] = z;
            }
            dataGraph.Add(dataFields);
        }
    }
}
