using UnityEngine;
using TMPro;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System;

public class RpsUI : MonoBehaviour
{
    public HandXRMgr handXRMgr;
    public GraphMgr graphMgr;
    public ScoreDisplaysMgr scoreDisplaysMgr;
    public GameObject quadRock;
    public GameObject quadPaper;
    public GameObject quadScissors;
    public GameObject quadScreensaver;
    public GameObject quadRecord;
    public GameObject quadGesture;
    public GameObject quadThrow;
    public GameObject quadGame;
    public GameObject quadWorld;
    int cntFlash;
    bool ynFlash;
    int cntCountDown;
    int cntFrames;
    public Material matHighlight;
    public Material matHighlightRed;
    public TMP_Text textCountdown;
    public TMP_Text textInfo;
    public TMP_Text textDebug;
    public TMP_Text textTime;
    AudioSource audioSource;
    public AudioClip clipPing;
    public AudioClip clipTick;
    public AudioClip clipYeah;
    public AudioClip clipBoo;
    public AudioClip clipBoing;
    public GameObject hands;
    int nTestPlayback;
    public GameObject gridPrefab;
    List<GameObject> grid = new List<GameObject>();
    GameObject gridParent;
    int cntFps;
    int cntFpsCurrent;
    bool ynRecordPressed;
    public Material matWorld;
    public Material matWorldRock;
    public Material matWorldPaper;
    public Material matWorldScissors;
    public GameObject sidePanel;
    int nTest;
    GestureType gestureLast;
    GestureThrowType gestureThrowLast;
    float timestampLastMoved;
    float screensaverDelay = 10;
    public bool ynScreensaver;
    public GameObject borderRoundOuter;
    public Material matBorderRoundOuterGreen;
    public Material matBorderRoundOuterScreensaver;
    public GameObject passthrough;
    bool ynPassthrough = true;

    private void Awake()
    {
        Application.targetFrameRate = 120;
        Debug.Log("persistentDataPath:" + Application.persistentDataPath + "\n");
        audioSource = GetComponent<AudioSource>();
        handXRMgr.gameObject.SetActive(false);  // needed for some reason, avoids camera sinking down forever !
        timestampLastMoved = Time.realtimeSinceStartup; // - screensaverDelay;
    }

    void Start()
    {
        SetupRecenter();
        PlayYeah();
        ShowFileInfo();
        CreateGrid();
        UnHighlightAllButtons();
        RockPressed();
        GesturePressed();
        AdjustButtonsFromHandXRMgrParameters();
        InvokeRepeating(nameof(FpsAndVersion), 1, 1);
        if (Application.isEditor)
        {
            InvokeRepeating(nameof(TestMoved), 20, 20);
            //InvokeRepeating(nameof(GamePressed), 10, 10);
        }
        else
        {
            Invoke(nameof(PoseHandleRelativeToCamera), .5f);
        }
    }

    void Update()
    {
        if (cntFrames == 1)
        {
            handXRMgr.gameObject.SetActive(true); // needed for some reason, avoids camera sinking down forever !
        }
        UpdateMoved();
        UpdateScreensaver();
        cntFrames++;
        cntFps++;
    }

    void TestMoved()
    {
        handXRMgr.xrRootLiveLeft.transform.Translate(0, 0, .03f);
    }

    public void PassthruPressed()
    {
        ynPassthrough = !ynPassthrough;
        passthrough.SetActive(ynPassthrough);
    }

    void UpdateMoved()
    {
        if (handXRMgr.ynMoved)
        {
            timestampLastMoved = Time.realtimeSinceStartup;
        }
    }

    void UpdateScreensaver()
    {
        float elapsed = Time.realtimeSinceStartup - timestampLastMoved;
        if (elapsed > screensaverDelay)
        {
            if (!ynScreensaver)
            {
                ynScreensaver = true;
                UnHighlightAllButtons();
                handXRMgr.LoadDataHandsScreensaver();
                borderRoundOuter.GetComponentInChildren<Renderer>().material = matBorderRoundOuterScreensaver;
            }
        }
        else
        {
            if (ynScreensaver)
            {
                ynScreensaver = false;
                AdjustButtonsFromHandXRMgrParameters();
                borderRoundOuter.GetComponentInChildren<Renderer>().material = matBorderRoundOuterGreen;
            }
        }
    }

    void TestPressed()
    {
        if (nTest == 0) RockPressed();
        if (nTest == 1) PaperPressed();
        if (nTest == 2) ScissorsPressed();
        nTest++;
        if (nTest >= 3) nTest = 0;
    }

    void FpsAndVersion()
    {
        cntFpsCurrent = cntFps;
        SetVersion();
        SetTime();
        cntFps = 0;
        Debug.Log("fps:" + cntFpsCurrent + "\n");
    }

    void SetTime()
    {
        textTime.text = DateTime.Now.ToString("h:mm:ss tt");
    }

    void SetVersion()
    {
        string f1 = "<color=green>";
        string f2 = "</color><b>";
        string f3 = "</b>";
        string s = "\n";
        string txt = "";
        txt += "<color=green>productName: " + f2 + Application.productName + f3;
        txt += s + f1 + "version: " + f2 + Application.version + f3;
        txt += s + f1 + "unityVersion: " + f2 + Application.unityVersion + f3;
        txt += s + f1 + "Meta XR SDK version: " + f2 + "77.0" + f3;
        txt += s + f1 + "fps: " + f2 + cntFpsCurrent + f3;
        txt += s + f1 + "prototyper: " + f2 + "me@amre-amer.com" + f3;
        txt += s + f1 + "deviceModel: <b>" + f2 + SystemInfo.deviceModel + f3;
        txt += s + f1 + "deviceName: <b>" + f2 + SystemInfo.deviceName + f3;
        txt += s + f1 + "deviceType: <b>" + f2 + SystemInfo.deviceType + f3;
        txt += s + f1 + "batteryLevel: <b>" + f2 + SystemInfo.batteryLevel + f3;
        txt += s + f1 + "processorCount: <b>" + f2 + SystemInfo.processorCount + f3;
        txt += s + f1 + "processorFrequency: <b>" + f2 + SystemInfo.processorFrequency + f3;
        txt += s + f1 + "processorManufacturer: <b>" + f2 + SystemInfo.processorManufacturer + f3;
        txt += s + f1 + "processorModel: <b>" + f2 + SystemInfo.processorModel + f3;
        txt += s + f1 + "processorType: <b>" + f2 + SystemInfo.processorType + f3;
        txt += s + f1 + "graphicsDeviceName: <b>" + f2 + SystemInfo.graphicsDeviceName + f3;
        txt += s + f1 + "graphicsMemorySize: <b>" + f2 + SystemInfo.graphicsMemorySize + f3;
        txt += s + f1 + "graphicsDeviceVendor: <b>" + f2 + SystemInfo.graphicsDeviceVendor + f3;
        txt += s + f1 + "System.GC.GetTotalMemory(true): <b>" + f2 + GC.GetTotalMemory(true).ToString("N0") + f3;
        txt += s + f1 + "screensaver: <b>" + f2 + (Time.realtimeSinceStartup - timestampLastMoved).ToString("F0") + " sec" + f3;
        SetTextDebug(txt);
    }

    void SetupRecenter()
    {
        if (!Application.isEditor)
        {
            OVRManager.display.RecenteredPose += () =>
            {
                PoseHandleRelativeToCamera();
            };
        }
    }

    public void SetTextDebug(string txt)
    {
        textDebug.text = txt;
    }

    void CreateGrid()
    {
        gridParent = new GameObject("gridParent");
        gridParent.transform.SetParent(gridPrefab.transform.parent);
        gridPrefab.SetActive(true);
        float inch = .0254f;
        float delta = inch * 3;
        int numX = 9;
        int numY = 7;
        int numZ = 3;
        for (int nx = 0; nx < numX; nx++)
        {
            for (int ny = 0; ny < numY; ny++)
            {
                for (int nz = 0; nz < numZ; nz++)
                {
                    float x = (nx - (numX - 1) / 2f) * delta;
                    if (Mathf.Abs(x) > delta)
                    {
                        GameObject go = Instantiate(gridPrefab, gridParent.transform);
                        float y = (ny - (numY + 1) / 2f) * delta;
                        float z = nz * delta;
                        Vector3 posL = new(x, y, z);
                        Vector3 pos = transform.TransformPoint(posL);
                        go.transform.position = pos;
                        grid.Add(go);
                    }
                }
            }
        }
        gridPrefab.SetActive(false);
    }

    void TurnOnOffGrid(bool yn)
    {
        gridParent.gameObject.SetActive(yn);
    }

    public void ShowFileInfo()
    {
        string[] files = Directory.GetFiles(Application.persistentDataPath, "*.csv").OrderByDescending(d => new FileInfo(d).LastWriteTime).ToArray();
        string txt = "<mspace=.55em>Files: 1-elapsed + [6x(xyz,xyz) x 26 joints + 6x(xyz,xyz) wrist] x 2 hands: 1 + 2*162 = 325 fields";
        string s = "\n";
        txt += s + "<color=green>" + "filename".PadRight(30);
        txt += "size".PadRight(20);
        txt += "recs x fields duration fps".PadRight(30);
        txt += "updated</color>";
        foreach (string filespec in files)
        {
            FileInfo fileInfo = new FileInfo(filespec);
            txt += s + Path.GetFileName(filespec).PadRight(30);
            txt += (fileInfo.Length.ToString("N0") + " bytes").PadRight(20);
            txt += GetNumRecordsNumFieldsDurationFps(filespec).PadRight(30);
            txt += File.GetLastWriteTime(filespec);
        }
        textInfo.text = txt;
    }

    string GetNumRecordsNumFieldsDurationFps(string filespec)
    {
        string txtAll = File.ReadAllText(filespec);
        string[] lines = txtAll.Split('\n');
        int numRecords = lines.Length;
        int numFields = 0;
        float duration = 0;
        float fps = 0;
        if (numRecords > 0)
        {
            string line = lines[numRecords - 1];
            string[]fields = line.Split(',');
            numFields = fields.Length;
            if (numFields > 0)
            {
                bool ynNumeric = float.TryParse(fields[0], out duration);
                if (ynNumeric)
                {
                    fps = numRecords / duration;
                }
            }
        }
        string txt = numRecords + " x " + numFields;
        if (filespec.Contains("training"))
        {
            txt += new string(' ', 23);
        } else
        {
            txt += "  " + duration.ToString("F2");
            txt += " sec " + fps.ToString("F1") + " fps";
        }
        return txt;
    }

    public void PoseHandleRelativeToCamera()
    {
        Vector3 pos = new Vector3(0, 0, .3f);
        transform.position = Camera.main.transform.TransformPoint(pos);
        transform.LookAt(Camera.main.transform.position);
        transform.Rotate(0, 180, 0);
        LevelEuler(gameObject);
        PlayPing();
    }

    void LevelEuler(GameObject go)
    {
        Vector3 eul = go.transform.localEulerAngles;
        eul.x = 0;
        eul.z = 0;
        go.transform.localEulerAngles = eul;
    }

    void AdjustButtonsFromHandXRMgrParameters()
    {
        switch (handXRMgr.gestureCurrent)
        {
            case GestureType.rock:
                RockPressed();
                break;
            case GestureType.paper:
                PaperPressed();
                break;
            case GestureType.scissors:
                ScissorsPressed();
                break;
            case GestureType.screensaver:
                ScreensaverPressed();
                break;
        }
        switch (handXRMgr.gestureThrowCurrent)
        {
            case GestureThrowType._gesture:
                GesturePressed();
                break;
            case GestureThrowType._throw:
                ThrowPressed();
                break;
        }
    }

    public void PlayTick()
    {
        audioSource.PlayOneShot(clipTick);
    }

    public void PlayPing()
    {
        audioSource.PlayOneShot(clipPing);
    }

    public void PlayYeah()
    {
        audioSource.PlayOneShot(clipYeah);
    }

    public void PlayBoo()
    {
        audioSource.PlayOneShot(clipBoo);
    }

    public void PlayBoing()
    {
        audioSource.PlayOneShot(clipBoing);
    }

    void UnHighlightAllButtons()
    {
        bool yn = false;
        HighlightButton(quadRock, yn);
        HighlightButton(quadPaper, yn);
        HighlightButton(quadScissors, yn);
        HighlightButton(quadScreensaver, yn);
        HighlightButton(quadRecord, yn);
        HighlightButton(quadGesture, yn);
        HighlightButton(quadThrow, yn);
        HighlightButton(quadGame, yn);
        HighlightButton(quadWorld, yn);
        textCountdown.gameObject.SetActive(false);
    }

    public void HighlightButton(GameObject quad, bool yn)
    {
        quad.SetActive(yn);
        //PlayTick();
    }

    void Rotate180ForGame(bool yn)
    {
        if (yn)
        {
            handXRMgr.transform.localEulerAngles = new Vector3(0, 180, 0);
            handXRMgr.transform.localPosition = new Vector3(0, 0, .2f);
        }
        else
        {
            handXRMgr.transform.localEulerAngles = new Vector3(0, 0, 0);
            handXRMgr.transform.localPosition = new Vector3(0, 0, 0);
        }
    }

    void ShowHideButton(GameObject quad, bool yn)
    {
        quad.transform.parent.gameObject.SetActive(yn);
    }

    void ShowHideGameButtons(bool yn)
    {
        ShowHideButton(quadRock, !yn);
        ShowHideButton(quadPaper, !yn);
        ShowHideButton(quadScissors, !yn);
        ShowHideButton(quadScreensaver, !yn);
        ShowHideButton(quadRecord, !yn);
        ShowHideButton(quadGesture, !yn);
        ShowHideButton(quadThrow, !yn);
        ShowHideButton(quadGame, true);
        ShowHideButton(quadWorld, true);
    }

    void SaveCurrentGestureAndGestureThrow()
    {
        gestureLast = handXRMgr.gestureCurrent;
        gestureThrowLast = handXRMgr.gestureThrowCurrent;
    }

    void RestoreCurrentGestureAndGestureThrow()
    {
        handXRMgr.gestureCurrent = gestureLast;
        handXRMgr.gestureThrowCurrent = gestureThrowLast;
        AdjustButtonsFromHandXRMgrParameters();
    }

    public void GamePressed()
    {
        RecordStop(); // ? needed ?
        if (!handXRMgr.ynGame)
        {
            SaveCurrentGestureAndGestureThrow();
        }
        handXRMgr.GamePressed();
        quadGame.SetActive(handXRMgr.ynGame);
        Rotate180ForGame(handXRMgr.ynGame);
        ShowHideGameButtons(handXRMgr.ynGame);
        TurnOnOffGrid(!handXRMgr.ynGame);
        if (!handXRMgr.ynGame)
        {
            RestoreCurrentGestureAndGestureThrow();
        }
    }

    public void RecordPressed()
    {
        if (cntFlash > 0)
        {
            RecordStop();
            return;
        }
        HighlightButton(quadRecord, handXRMgr.ynRecordStart);
        FlashRecordStart();
    }

    void FlashRecordStart()
    {
        cntFlash = 0;
        ynFlash = true;
        quadRecord.GetComponent<Renderer>().material = matHighlightRed;
        FlashRecord();
    }

    void FlashRecord()
    {
        ynFlash = !ynFlash;
        quadRecord.SetActive(ynFlash);
        if (cntFlash <= 6)
        {
            Invoke(nameof(FlashRecord), .5f);
            cntFlash++;
        } else
        {
            RecordStartPressed();
        }
    }

    void RecordStartPressed()
    {
        handXRMgr.RecordPressed();
        textCountdown.gameObject.SetActive(true);
        cntCountDown = handXRMgr.durationRecord;
        AdjustTextCountDown();
    }

    void AdjustTextCountDown()
    {
        if (cntCountDown > 0)
        {
            textCountdown.text = cntCountDown.ToString();
            cntCountDown--;
            Invoke(nameof(AdjustTextCountDown), 1);
        }
        else
        {
            RecordStop();
        }
    }

    public void RecordStop()
    {
        cntFlash = 0;
        CancelInvoke(nameof(FlashRecord));
        CancelInvoke(nameof(AdjustTextCountDown));
        HighlightButton(quadRecord, false);
        textCountdown.gameObject.SetActive(false);
        quadRecord.GetComponent<Renderer>().material = matHighlight;
    }

    public void GesturePressed()
    {
        handXRMgr.GesturePressed();
        HighlightButton(quadGesture, true);
        HighlightButton(quadThrow, false);
    }

    public void ThrowPressed()
    {
        handXRMgr.ThrowPressed();
        HighlightButton(quadGesture, false);
        HighlightButton(quadThrow, true);
    }

    public void RockPressed()
    {
        handXRMgr.RockPressed();
        HighlightButton(quadRock, true);
        HighlightButton(quadPaper, false);
        HighlightButton(quadScissors, false);
        HighlightButton(quadScreensaver, false);
    }

    public void PaperPressed()
    {
        handXRMgr.PaperPressed();
        HighlightButton(quadRock, false);
        HighlightButton(quadPaper, true);
        HighlightButton(quadScissors, false);
        HighlightButton(quadScreensaver, false);
    }

    public void ScissorsPressed()
    {
        handXRMgr.ScissorsPressed();
        HighlightButton(quadRock, false);
        HighlightButton(quadPaper, false);
        HighlightButton(quadScissors, true);
        HighlightButton(quadScreensaver, false);
    }

    public void ScreensaverPressed()
    {
        handXRMgr.ScreensaverPressed();
        HighlightButton(quadRock, false);
        HighlightButton(quadPaper, false);
        HighlightButton(quadScissors, false);
        HighlightButton(quadScreensaver, true);
    }
}
