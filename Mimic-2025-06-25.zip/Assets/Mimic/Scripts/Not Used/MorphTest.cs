using UnityEngine;
using TMPro;

public class MorphTest : MonoBehaviour
{
    public HandMgr handMgrSingle;
    public HandMgr handMgrSource;
    public HandMgr handMgrTarget;
    public TMP_Text textInfo;
    int cntFrames;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        InvokeRepeating(nameof(TestMorphSingle), 2, 6);
        InvokeRepeating(nameof(TestMorphSourceTarget), 2, 6);
    }

    // Update is called once per frame
    void Update()
    {
        UpdateInfo();
        cntFrames++;
    }

    void TestMorphSingle()
    {
        handMgrSingle.StartMorphEndToStart(
            handMgrSingle,
            handMgrSingle,
            handMgrSingle.data.Count - 1,
            0,
            5);
    }

    void TestMorphSourceTarget()
    {
        handMgrTarget.StartMorphEndToStart(
            handMgrSource,
            handMgrTarget,
            handMgrSource.data.Count - 1,
            0,
            5);
    }

    void UpdateInfo()
    {
        string txt = "";
        string s = "\n";
        txt += s + "cntFrames:" + cntFrames;
        //txt += s + "ynMorph:" + handMgr.ynMorph;
        //txt += s + "ynMorph:" + handMgr.ynMorph;
        //txt += s + "morphFraction:" + handMgr.morphFraction;
        //txt += s + "morphDuration:" + handMgr.morphDuration;
        textInfo.text = txt;
    }
}
