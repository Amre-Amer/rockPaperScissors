using System.IO;
using UnityEngine;

public class CSVtoPersistent : MonoBehaviour
{
    /// <summary>
    ///  Out dated
    /// </summary>
    public HandXRMgr handXRMgr;
    GestureType gestureCurrent;
    GestureThrowType gestureThrowCurrent;
    LeftRightType leftRightCurrent;
    string filespec;
    TextAsset textAssetCurrent;
    public TextAsset textAssetRockGestureLeft;
    public TextAsset textAssetRockGestureRight;
    public TextAsset textAssetRockThrowLeft;
    public TextAsset textAssetRockThrowRight;
    public TextAsset textAssetPaperGestureLeft;
    public TextAsset textAssetPaperGestureRight;
    public TextAsset textAssetPaperThrowLeft;
    public TextAsset textAssetPaperThrowRight;
    public TextAsset textAssetScissorsGestureLeft;
    public TextAsset textAssetScissorsGestureRight;
    public TextAsset textAssetScissorsThrowLeft;
    public TextAsset textAssetScissorsThrowRight;
    public TextAsset textAssetScreensaverLeft;
    public TextAsset textAssetScreensaverRight;
    bool ynScreensaver;

    public void StartCopy()
    {
        CopyResourceCSVToPersistentDataPathAll();
    }

    void CopyResourceCSVToPersistentDataPathAll()
    {
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._gesture, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._gesture, LeftRightType.right);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._throw, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.rock, GestureThrowType._throw, LeftRightType.right);

        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._gesture, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._gesture, LeftRightType.right);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._throw, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.paper, GestureThrowType._throw, LeftRightType.right);

        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._gesture, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._gesture, LeftRightType.right);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._throw, LeftRightType.left);
        CopyResourceCSVToPersistentDataPath(GestureType.scissors, GestureThrowType._throw, LeftRightType.right);

        ynScreensaver = true;

        leftRightCurrent = LeftRightType.left;
        //filespec = handXRMgr.SetFilenameAndFilespec(gestureCurrent, gestureThrowCurrent, leftRightCurrent, ynScreensaver);
        SetTextAssetCurrent();
        SaveResourceCSVtoPersistentDataPath();

        leftRightCurrent = LeftRightType.right;
        //filespec = handXRMgr.SetFilenameAndFilespec(gestureCurrent, gestureThrowCurrent, leftRightCurrent, ynScreensaver);
        SetTextAssetCurrent();
        SaveResourceCSVtoPersistentDataPath();

        ynScreensaver = false;
    }

    void CopyResourceCSVToPersistentDataPath(GestureType gesture, GestureThrowType gestureThrow, LeftRightType leftRight)
    {
        SetParameters(gesture, gestureThrow, leftRight);
        //filespec = handXRMgr.SetFilenameAndFilespec(gesture, gestureThrow, leftRight, ynScreensaver);
        SetTextAssetCurrent();
        SaveResourceCSVtoPersistentDataPath();
    }

    void SaveResourceCSVtoPersistentDataPath()
    {
        if (!textAssetCurrent) return;
        File.WriteAllText(filespec, textAssetCurrent.text);
        //Debug.Log("CSVtoPersistent:" + filespec + "\n");
    }

    void SetTextAssetCurrent()
    {
        textAssetCurrent = null;
        if (ynScreensaver)
        {
            if (leftRightCurrent == LeftRightType.left)
            {
                textAssetCurrent = textAssetScreensaverLeft;
            }
            if (leftRightCurrent == LeftRightType.right)
            {
                textAssetCurrent = textAssetScreensaverRight;
            }
            return;
        }
        if (gestureCurrent == GestureType.rock)
        {
            if (gestureThrowCurrent == GestureThrowType._gesture)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetRockGestureLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetRockGestureRight;
                }
            }
            if (gestureThrowCurrent == GestureThrowType._throw)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetRockThrowLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetRockThrowRight;
                }
            }
        }
        if (gestureCurrent == GestureType.paper)
        {
            if (gestureThrowCurrent == GestureThrowType._gesture)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetPaperGestureLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetPaperGestureRight;
                }
            }
            if (gestureThrowCurrent == GestureThrowType._throw)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetPaperThrowLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetPaperThrowRight;
                }
            }
        }
        if (gestureCurrent == GestureType.scissors)
        {
            if (gestureThrowCurrent == GestureThrowType._gesture)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetScissorsGestureLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetScissorsGestureRight;
                }
            }
            if (gestureThrowCurrent == GestureThrowType._throw)
            {
                if (leftRightCurrent == LeftRightType.left)
                {
                    textAssetCurrent = textAssetScissorsThrowLeft;
                }
                if (leftRightCurrent == LeftRightType.right)
                {
                    textAssetCurrent = textAssetScissorsThrowRight;
                }
            }
        }
    }

    void SetParameters(GestureType gesture, GestureThrowType gestureThrow, LeftRightType leftRight)
    {
        if (gesture == GestureType.rock) gestureCurrent = GestureType.rock;
        if (gesture == GestureType.paper) gestureCurrent = GestureType.paper;
        if (gesture == GestureType.scissors) gestureCurrent = GestureType.scissors;
        if (gestureThrow == GestureThrowType._gesture) gestureThrowCurrent = GestureThrowType._gesture;
        if (gestureThrow == GestureThrowType._throw) gestureThrowCurrent = GestureThrowType._throw;
        if (leftRight == LeftRightType.left) leftRightCurrent = LeftRightType.left;
        if (leftRight == LeftRightType.right) leftRightCurrent = LeftRightType.right;
    }
}
