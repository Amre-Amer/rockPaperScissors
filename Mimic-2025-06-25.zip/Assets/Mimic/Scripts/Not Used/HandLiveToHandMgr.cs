using System.Collections.Generic;
using Oculus.Interaction;
using UnityEngine;

public class HandLiveToHandMgr : MonoBehaviour
{
    public OVRSkeleton handLiveLeft;
    public OVRSkeleton handLiveRight;
    public OVRSkeleton handLeft;
    public OVRSkeleton handRight;
    public TextAsset textAssetLeft;
    public TextAsset textAssetRight;
    List<List<float>> dataLeft = new List<List<float>>();
    List<List<float>> dataRight = new List<List<float>>();
    float startTimeLeft;
    float startTimeRight;
    bool ynTest;
    public HandVisual handVisualLeft;
    public HandVisual handVisualRight;
    public HandVisual handVisualRightTest;
    enum LeftRight
    {
        left,
        right
    }
    LeftRight leftRight;
    int[] indexesTraining = new int[] { 7, 12, 17, 22 };
    int cntFrames;
    TextAsset textAssetLeftLast;
    TextAsset textAssetRightLast;

    void Start()
    {
        ynTest = false;
    }

    void Update()
    {
        UpdateTextAssetsChanged();
        if (ynTest)
        {
            UpdateTestLR();
        } else
        {
            HandLiveToHandLR();
            UpdatePlaybackLR();
        }
        Test();
        cntFrames++;
        textAssetLeftLast = textAssetLeft;
        textAssetRightLast = textAssetRight;
    }

    void Test()
    {
        OVRHand ovrHand = handVisualRightTest.GetComponent<OVRHand>();
        Debug.Log("ovrHand:" + ovrHand + "\n");
        for(int n = 0; n < handVisualRightTest.Joints.Count; n++)
        {
            Vector3 eulL = handVisualRightTest.Joints[n].transform.localEulerAngles;
            if (IsUsedForTraining(n))
            {
                float ang = 80 + 10 * Mathf.Cos(cntFrames * Mathf.Deg2Rad);
                ang = NormalizeAngle(ang);
                eulL.x = ang;
            }
            handVisualRightTest.Joints[n].transform.localEulerAngles = eulL;
        }
    }

    public float NormalizeAngle(float vv)
    {
        float v = vv;
        if (v < -180) v += 360;
        if (v > 180) v -= 360;
        return v;
    }

    void UpdateTestLR()
    {
        leftRight = LeftRight.left;
        UpdateTest();
        leftRight = LeftRight.right;
        UpdateTest();
    }

    void HandLiveToHandLR()
    {
        leftRight = LeftRight.left;
        HandLiveToHand();
        leftRight = LeftRight.right;
        HandLiveToHand();
    }

    void UpdatePlaybackLR()
    {
        //Debug.Log("UpdatePlaybackLR\n");
        leftRight = LeftRight.left;
        UpdatePlayback();
        leftRight = LeftRight.right;
        UpdatePlayback();
    }

    void LoadDataLR() {
        Debug.Log("LoadDataLR\n");
        leftRight = LeftRight.left;
        LoadData();
        leftRight = LeftRight.right;
        LoadData();
    }

    void UpdateTextAssetsChanged()
    {
        if (textAssetLeftLast == textAssetLeft && textAssetRightLast == textAssetRight) return;
        LoadDataLR();
    }

    void UpdateTest()
    {
        OVRSkeleton hand = null;
        HandVisual handVisual = null;
        switch (leftRight)
        {
            case LeftRight.left:
                handVisual = handVisualLeft;
                break;
            case LeftRight.right:
                handVisual = handVisualRight;
                break;
        }
        if (Application.isEditor)
        {
            for (int n = 0; n < handVisual.Joints.Count; n++)
            {
                Vector3 eulL = handVisual.Joints[n].transform.localEulerAngles;
                if (IsUsedForTraining(n))
                {
                    float ang = 100 + 30 * Mathf.Cos(cntFrames * Mathf.Deg2Rad);
                    eulL.x = ang;
                }
                handVisual.Joints[n].transform.localEulerAngles = eulL;
            }
        }
        else
        {
            for (int n = 0; n < hand.Bones.Count; n++)
            {
                Vector3 eulL = hand.Bones[n].Transform.localEulerAngles;
                if (IsUsedForTraining(n))
                {
                    float ang = 100 + 30 * Mathf.Cos(cntFrames * Mathf.Deg2Rad);
                    eulL.x = ang;
                }
                hand.Bones[n].Transform.localEulerAngles = eulL;
            }
        }
    }

    public bool IsUsedForTraining(int n)
    {
        bool yn = false;
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            if (indexesTraining[i] == n)
            {
                yn = true;
                break;
            }
        }
        return yn;
    }

    void UpdatePlayback()
    {
        bool ynFound = false;
        float startTime = 0;
        List<List<float>> data = null;
        OVRSkeleton hand = null;
        HandVisual handVisual = null;
        switch (leftRight)
        {
            case LeftRight.left:
                startTime = startTimeLeft;
                data = dataLeft;
                hand = handLeft;
                handVisual = handVisualLeft;
                break;
            case LeftRight.right:
                startTime = startTimeRight;
                data = dataRight;
                hand = handRight;
                handVisual = handVisualRight;
                break;
        }
        float elapsedTarget = Time.realtimeSinceStartup - startTime;
        for(int n = 0; n < data.Count; n++)
        {
            List<float> record = data[n];
            float elapsed = record[0];
            if (elapsed >= elapsedTarget)
            {
                if (Application.isEditor)
                {
                    DataToHandVisual(data, n, handVisual);
                }
                else
                {
                    DataToHand(data, n, hand);
                }
                ynFound = true;
                break;
            }
        }
        if (!ynFound)
        {
            switch (leftRight)
            {
                case LeftRight.left:
                    startTimeLeft = Time.realtimeSinceStartup;
                    break;
                case LeftRight.right:
                    startTimeRight = Time.realtimeSinceStartup;
                    break;
            }
        }
    }

    void DataToHandVisual(List<List<float>> data, int nRecord, HandVisual handVisual)
    {
        List<float> record = data[nRecord];
        int countBones = handVisual.Joints.Count;
        for (int n = 0; n < countBones; n++)
        {
            float x = record[1 + n + 3 + 0];
            float y = record[1 + n + 3 + 1];
            float z = record[1 + n + 3 + 2];
            Vector3 eulL = new(x, y, z);
            handVisual.Joints[n].transform.localEulerAngles = eulL;
        }
        float xPos = record[1 + countBones * 3 + 0];
        float yPos = record[1 + countBones * 3 + 1];
        float zPos = record[1 + countBones * 3 + 2];
        Vector3 wristLocalPosition = new(xPos, yPos, zPos);
        float xEul = record[1 + (countBones + 1) * 3 + 0];
        float yEul = record[1 + (countBones + 1) * 3 + 1];
        float zEul = record[1 + (countBones + 1) * 3 + 2];
        Vector3 wristLocalEulers = new(xEul, yEul, zEul);
        GameObject parentOrig = handVisual.transform.parent.gameObject;
        handVisual.transform.SetParent(transform);
        handVisual.transform.localPosition = wristLocalPosition;
        handVisual.transform.localEulerAngles = wristLocalEulers;
        handVisual.transform.SetParent(parentOrig.transform);
    }

    void DataToHand(List<List<float>>data, int nRecord, OVRSkeleton hand)
    {
        List<float> record = data[nRecord];
        int countBones = hand.Bones.Count;
        for (int n = 0; n < countBones; n++)
        {
            float x = record[1 + n + 3 + 0];
            float y = record[1 + n + 3 + 1];
            float z = record[1 + n + 3 + 2];
            Vector3 eulL = new(x, y, z);
            hand.Bones[n].Transform.localEulerAngles = eulL;
        }
        float xPos = record[1 + countBones * 3 + 0];
        float yPos = record[1 + countBones * 3 + 1];
        float zPos = record[1 + countBones * 3 + 2];
        Vector3 wristLocalPosition = new(xPos, yPos, zPos);
        float xEul = record[1 + (countBones + 1) * 3 + 0];
        float yEul = record[1 + (countBones + 1) * 3 + 1];
        float zEul = record[1 + (countBones + 1) * 3 + 2];
        Vector3 wristLocalEulers = new(xEul, yEul, zEul);
        GameObject parentOrig = hand.transform.parent.gameObject;
        hand.transform.SetParent(transform);
        hand.transform.localPosition = wristLocalPosition;
        hand.transform.localEulerAngles = wristLocalEulers;
        hand.transform.SetParent(parentOrig.transform);
    }

    void LoadData()
    {
        TextAsset textAsset = null;
        List<List<float>> data = null;
        switch (leftRight)
        {
            case LeftRight.left:
                textAsset = textAssetLeft;
                data = dataLeft;
                break;
            case LeftRight.right:
                textAsset = textAssetRight;
                data = dataRight;
                break;
        }
        string[] txtLines = textAsset.text.Split('\n');
        data.Clear();
        for(int n = 0; n < txtLines.Length; n++)
        {
            string[] stuff = txtLines[n].Split(',');
            List<float> record = new List<float>();
            for(int nn = 0; nn < stuff.Length; nn++)
            {
                float v = float.Parse(stuff[nn]);
                record.Add(v);
            }
            data.Add(record);
        }
    }

    void HandLiveToHand()
    {
        OVRSkeleton handLive = null;
        OVRSkeleton hand = null;
        switch (leftRight)
        {
            case LeftRight.left:
                handLive = handLiveLeft;
                hand = handLeft;
                break;
            case LeftRight.right:
                handLive = handLiveRight;
                hand = handRight;
                break;
        }
        for (int n = 0; n < handLive.Bones.Count; n++)
        {
            Vector3 eulL = handLive.Bones[n].Transform.localEulerAngles;
            hand.Bones[n].Transform.localEulerAngles = eulL;
        }
        //GameObject parentOrig = skeleton.transform.parent.gameObject;
        //skeleton.transform.SetParent(transform);
        //Vector3 posW = skeleton.transform.localPosition;
        //Vector3 eulW = skeleton.transform.localEulerAngles;
        //skeleton.transform.SetParent(parentOrig.transform);
        //dataRecord.Add(posW.x);
        //dataRecord.Add(posW.y);
        //dataRecord.Add(posW.z);
        //dataRecord.Add(eulW.x);
        //dataRecord.Add(eulW.y);
        //dataRecord.Add(eulW.z);
        //data.Add(dataRecord);
    }
}
