using System.Collections.Generic;
using Oculus.Interaction;
using UnityEngine;

public class HandXRMgr : MonoBehaviour
{
    public NNMgr nnMgr;
    public RpsUI rpsUI;
    public GraphMgr graphMgr;
    public ScoreDisplaysMgr scoreDisplaysMgr;
    public FileMgr fileMgr;
    public bool ynLoop;
    public bool ynRecordStart;
    public bool ynTest;
    public bool ynMorph;
    public bool ynThrow;
    public bool ynGame;
    public bool ynRecord;
    public bool ynPlayback;
    public bool ynMoved;
    public float timeStartPlayback;
    public float duration;
    public float morphStartTime;
    public float morphDuration;
    public int frameCurrent;
    public int numRecords;
    public int numFields;
    public int nOutput;
    public int durationRecord;
    public HandVisual handLeft;
    public HandVisual handRight;
    [HideInInspector]
    public HandVisual handLive;
    public HandVisual handLiveLeft;
    public HandVisual handLiveRight;
    public GameObject xrRootLiveLeft;
    public GameObject xrRootLiveRight;
    public GestureType gestureCurrent;
    public GestureThrowType gestureThrowCurrent;
    public LeftRightType leftRightCurrent;
    public float[] inputsInfer;
    public float[] representativeInputsRock;
    public float[] representativeInputsPaper;
    public float[] representativeInputsScissors;
    public List<List<float>> dataRock = new();
    public List<List<float>> dataPaper = new();
    public List<List<float>> dataScissors = new();
    public GameObject markerPrefab;
    public int[] indexesTraining = new int[] { 7, 12, 17, 22 };
    public Material matRed;
    public Material matGreen;
    public Material matBlue;
    public Material matWhite;
    public Material matOrig;
    List<List<float>> dataHands = new();
    List<List<float>> dataHandsScreensaver = new();
    List<List<float>> dataSource;
    List<List<float>> dataTarget;
    List<GameObject> markers = new();
    float timeRecordStart;
    float timePlaybackStart;
    float morphFraction;
    int nRecordSource;
    int nRecordTarget;
    GameObject xrRootLive;
    bool ynThrowRandom;
    int nHandRoll;
    Material matInfer;
    float delayScore;
    float minMoveAutoLR = .01254f;
    float minMoveAutoFingersLR = 10;
    Vector3 posMoveLeftLast;
    Vector3 posMoveRightLast;
    float angMoveLeftFingersLast;
    float angMoveRightFingersLast;
    float timeStartEditor;
    int nInferEditor;

    private void Awake()
    {
        scoreDisplaysMgr.gameObject.SetActive(false);
    }

    void Start()
    {
        delayScore = 3.25f;
        durationRecord = 5;
        morphDuration = .5f;
        ynLoop = true;
        CreateMarkers();
    }

    void Update()
    {
        if (!ynRecord) UpdateMoved();
        if (!ynRecord) SetHandLiveAfterAutoDetect();
        UpdateRecord();
        if (!ynRecord) UpdatePlayback();
        if (!ynRecord) UpdateMarkers();
        //HandLiveToHand(); // for testing (simplest test) helped find pos
        if (!ynRecord) UpdateMorph();
        if (!ynRecord) UpdateInfer();
    }

    void UpdateMoved()
    {
        ynMoved = false;
        AutoDetectLeftRightCurrent();
        AutoDetectFingersLeftRightCurrent();
    }

    List<List<float>> GetDataCurrent()
    {
        List<List<float>> data;
        if (rpsUI.ynScreensaver)
        {
            data = dataHandsScreensaver;
        }
        else
        {
            data = dataHands;
        }
        return data;
    }

    void ScoreThrow()
    {
        int s = 0;
        if (nOutput == nHandRoll)
        {
            s = 0;
        }
        else
        {
            switch (nOutput)
            {
                case 0:
                    if (nHandRoll == 1) s = -1;
                    if (nHandRoll == 2) s = 1;
                    break;
                case 1:
                    if (nHandRoll == 2) s = -1;
                    if (nHandRoll == 0) s = 1;
                    break;
                case 2:
                    if (nHandRoll == 0) s = -1;
                    if (nHandRoll == 1) s = 1;
                    break;
            }
        }
        scoreDisplaysMgr.AddScore(s);
    }

    void SetHandLiveAfterAutoDetect()
    {
        if (Application.isEditor)
        {
            switch (leftRightCurrent)
            {
                case LeftRightType.left:
                    handLive = handLeft;
                    xrRootLive = handLeft.gameObject;
                    break;
                case LeftRightType.right:
                    handLive = handRight;
                    xrRootLive = handRight.gameObject;
                    break;
            }
        }
        else
        {
            switch (leftRightCurrent)
            {
                case LeftRightType.left:
                    handLive = handLiveLeft;
                    xrRootLive = xrRootLiveLeft;
                    break;
                case LeftRightType.right:
                    handLive = handLiveRight;
                    xrRootLive = xrRootLiveRight;
                    break;
            }
        }
        if (ynGame)
        {
            if (rpsUI.ynScreensaver)
            {
                handLeft.gameObject.SetActive(true);
                handRight.gameObject.SetActive(true);
            }
            else
            {
                switch (leftRightCurrent)
                {
                    case LeftRightType.left:
                        handLeft.gameObject.SetActive(true);
                        handRight.gameObject.SetActive(false);
                        break;
                    case LeftRightType.right:
                        handLeft.gameObject.SetActive(false);
                        handRight.gameObject.SetActive(true);
                        break;
                }
            }
        } else
        {
            HideHandsIfRecording();
        }
    }

    public float[] GetRepresentativeInputsForNOutput()
    {
        switch (nOutput)
        {
            case 0:
                return representativeInputsRock;
            case 1:
                return representativeInputsPaper;
            case 2:
                return representativeInputsScissors;
            default:
                return null;
        }
    }

    float[] GetAverageInputs()
    {
        if (dataHands.Count == 0) {
            return new float[] { 0, 25, 50, 75};
        }
        bool ynMid = false;
        float[] averageInputs = new float[indexesTraining.Length];
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            int j = indexesTraining[i];
            int nTraining = 1 + j * 6 + 3; // xEul for training
            if (ynMid)
            {
                int nRecordMid = dataHands.Count / 2;
                float v = dataHands[nRecordMid][nTraining];
                averageInputs[i] = v;
            }
            else
            {
                for (int nRecord = 0; nRecord < dataHands.Count; nRecord++)
                {
                    float v = dataHands[nRecord][nTraining];
                    averageInputs[i] += v;
                }
            }
        }
        if (!ynMid)
        {
            for (int i = 0; i < indexesTraining.Length; i++)
            {
                averageInputs[i] /= dataHands.Count;
            }
        }
        return averageInputs;
    }

    void AutoDetectLeftRightCurrent()
    {
        Vector3 posMoveLeft = xrRootLiveLeft.transform.position;
        Vector3 posMoveRight = xrRootLiveRight.transform.position;
        float distLeft = Vector3.Distance(posMoveLeft, posMoveLeftLast);
        float distRight = Vector3.Distance(posMoveRight, posMoveRightLast);
        if (distLeft > minMoveAutoLR)
        {
            ynMoved = true;
            leftRightCurrent = LeftRightType.left;
        }
        if (distRight > minMoveAutoLR)
        {
            ynMoved = true;
            leftRightCurrent = LeftRightType.right;
        }
        posMoveLeftLast = posMoveLeft;
        posMoveRightLast = posMoveRight;
    }

    void AutoDetectFingersLeftRightCurrent()
    {
        if (Application.isEditor) return;
        int n = indexesTraining[0];
        float angMoveLeftFingers = handLiveLeft.Joints[n].transform.localEulerAngles.x;
        angMoveLeftFingers = NormalizeAngle(angMoveLeftFingers);
        float angMoveRightFingers = handLiveRight.Joints[n].transform.localEulerAngles.x;
        angMoveRightFingers = NormalizeAngle(angMoveRightFingers);
        float deltaLeftFingers = Mathf.Abs(angMoveLeftFingers - angMoveLeftFingersLast);
        float deltaRightFingers = Mathf.Abs(angMoveRightFingers - angMoveRightFingersLast);
        if (deltaLeftFingers > minMoveAutoFingersLR)
        {
            ynMoved = true;
            leftRightCurrent = LeftRightType.left;
        }
        if (deltaRightFingers > minMoveAutoFingersLR)
        {
            ynMoved = true;
            leftRightCurrent = LeftRightType.right;
        }
        angMoveLeftFingersLast = angMoveLeftFingers;
        angMoveRightFingersLast = angMoveRightFingers;
    }

    void UpdateInfer()
    {
        if (ynRecord) return;
        if (rpsUI.ynScreensaver) return;
        HandLiveToInferInputs();
        graphMgr.UpdateGraph(inputsInfer);
        Infer();
        SetMatInferFromInferOutputs();
        SetMatHandInfer();
    }

    void Infer()
    {
        nOutput = nnMgr.InferWithNOutput(inputsInfer);
    }

    void SetMatInferFromInferOutputs()
    {
        matInfer = null;
        if (nOutput == 0) matInfer = matRed;
        if (nOutput == 1) matInfer = matGreen;
        if (nOutput == 2) matInfer = matBlue;
    }

    void SetMatHandInfer()
    {
        if (ynGame)
        {
            switch (leftRightCurrent)
            {
                case LeftRightType.left:
                    SetMatHand(handLiveLeft, matInfer);
                    SetMatHand(handLiveRight, matOrig);
                    break;
                case LeftRightType.right:
                    SetMatHand(handLiveLeft, matOrig);
                    SetMatHand(handLiveRight, matInfer);
                    break;
            }
        }
        else
        {
            switch (leftRightCurrent)
            {
                case LeftRightType.left:
                    SetMatHand(handLiveLeft, matInfer);
                    SetMatHand(handLiveRight, matWhite);
                    break;
                case LeftRightType.right:
                    SetMatHand(handLiveLeft, matWhite);
                    SetMatHand(handLiveRight, matInfer);
                    break;
            }
        }
    }

    void HandLiveToInferInputs()
    {
        if (Application.isEditor)
        {
            if (Time.realtimeSinceStartup - timeStartEditor > 1)
            {
                nInferEditor++;
                if (nInferEditor >= 3) nInferEditor = 0;
                if (nInferEditor == 0) inputsInfer = new float[] { 70, 70, 70, 70 };
                if (nInferEditor == 1) inputsInfer = new float[] { 0, 0, 0, 0 };
                if (nInferEditor == 2) inputsInfer = new float[] { 0, 0, 70, 70 };
                timeStartEditor = Time.realtimeSinceStartup;
            }
        }
        else
        {
            inputsInfer = new float[indexesTraining.Length];
            for (int n = 0; n < indexesTraining.Length; n++)
            {
                int nb = indexesTraining[n];
                float v = handLive.Joints[nb].transform.localEulerAngles.x;
                v = NormalizeAngle(v);
                inputsInfer[n] = v;
            }
        }
    }

    void SetRandomGesture()
    {
        nHandRoll = Random.Range(0, 3);
        switch (nHandRoll)
        {
            case 0:
                rpsUI.RockPressed();
                break;
            case 1:
                rpsUI.PaperPressed();
                break;
            case 2:
                rpsUI.ScissorsPressed();
                break;
        }
    }

    void ScoreAndShow()
    {
        rpsUI.PlayTick();
        ScoreThrow();
        scoreDisplaysMgr.ShowScoreDisplays();
    }

    void UpdateMorph()
    {
        if (!ynMorph) return;
        if (dataSource == null || dataSource.Count == 0) return;
        float elapsed = Time.realtimeSinceStartup - morphStartTime;
        for (int h = 0; h < 2; h++)
        {
            HandVisual hand = null;
            if (h == 0) hand = handLeft;
            if (h == 1) hand = handRight;
            if (elapsed >= morphDuration)
            {
                ynMorph = false;
                return;
            }
            morphFraction = elapsed / morphDuration;
            int count = hand.Joints.Count;
            for (int n = 0; n < count + 1; n++)
            {
                float posX = dataSource[nRecordSource][1 + (h * 162) + n * 6 + 0];
                float posY = dataSource[nRecordSource][1 + (h * 162) + n * 6 + 1];
                float posZ = dataSource[nRecordSource][1 + (h * 162) + n * 6 + 2];
                float eulX = dataSource[nRecordSource][1 + (h * 162) + n * 6 + 3];
                float eulY = dataSource[nRecordSource][1 + (h * 162) + n * 6 + 4];
                float eulZ = dataSource[nRecordSource][1 + (h * 162) + n * 6 + 5];
                Vector3 pos = new(posX, posY, posZ);
                Vector3 sourcePos = pos;
                Vector3 eul = new(eulX, eulY, eulZ);
                Quaternion sourceRotation = Quaternion.Euler(eul);
                posX = dataTarget[nRecordTarget][1 + (h * 162) + n * 6 + 0];
                posY = dataTarget[nRecordTarget][1 + (h * 162) + n * 6 + 1];
                posZ = dataTarget[nRecordTarget][1 + (h * 162) + n * 6 + 2];
                eulX = dataTarget[nRecordTarget][1 + (h * 162) + n * 6 + 3];
                eulY = dataTarget[nRecordTarget][1 + (h * 162) + n * 6 + 4];
                eulZ = dataTarget[nRecordTarget][1 + (h * 162) + n * 6 + 5];
                pos = new(posX, posY, posZ);
                Vector3 targetPos = pos;
                eul = new(eulX, eulY, eulZ);
                Quaternion targetRotation = Quaternion.Euler(eul);
                Quaternion interpolatedRotation = Quaternion.Slerp(sourceRotation, targetRotation, morphFraction);
                Vector3 interpolatedPosition = Vector3.Slerp(sourcePos, targetPos, morphFraction);
                if (n < count)
                {
                    hand.Joints[n].transform.localPosition = interpolatedPosition;
                    hand.Joints[n].transform.localRotation = interpolatedRotation;
                }
                else
                {
                    GameObject parentOrig = hand.transform.parent.gameObject;
                    hand.transform.SetParent(transform);
                    hand.transform.localPosition = interpolatedPosition;
                    hand.transform.localRotation = interpolatedRotation;
                    hand.transform.SetParent(parentOrig.transform);
                }
            }
        }
    }

    void UpdatePlayback()
    {
        if (!ynLoop) return;
        if (ynRecord) return;
        bool ynFound = false;
        List<List<float>> data = GetDataCurrent();
        float timeTarget = Time.realtimeSinceStartup - timeStartPlayback;
        for (int nLine = 0; nLine < dataHands.Count; nLine++)
        {
            List<float> dataLine = dataHands[nLine];
            float elapsed = dataLine[0];
            if (timeTarget < elapsed)
            {
                DataToHands(data, nLine);
                ynFound = true;
                break;
            }
        }
        if (!ynFound)
        {
            MorphThrowAndPlayback();
        }
    }

    void MorphThrowAndPlayback()
    {
        ynLoop = false; // to allow for morph (next) then RestartPlayback
        Invoke(nameof(RestartPlayback), morphDuration);
        MorphStartEndToStart();
    }

    void MorphStartEndToStart()
    {
        ynMorph = true;
        morphStartTime = Time.realtimeSinceStartup;
        List<List<float>> data = GetDataCurrent();
        if (ynThrow)
        {
            dataSource = new(data);
            if (ynThrowRandom)
            {
                SetRandomGesture();
                fileMgr.LoadDataFromPersistentFile();
            }
            dataTarget = data;
            Invoke(nameof(ScoreAndShow), morphDuration + delayScore);
        }
        else
        {
            dataSource = data;
            dataTarget = data;
        }
        nRecordSource = dataSource.Count - 1;
        nRecordTarget = 0;
    }

    void RestartPlayback()
    {
        timeStartPlayback = Time.realtimeSinceStartup;
        ynLoop = true;
    }

    public void SetMatHand(HandVisual hand, Material mat)
    {
        hand.GetComponentInChildren<SkinnedMeshRenderer>().material = mat;
    }

    void HandLiveToHand(HandVisual hand)
    {
        for (int n = 0; n < handLive.Joints.Count; n++)
        {
            Vector3 posL = handLive.Joints[n].transform.localPosition;
            Vector3 eulL = handLive.Joints[n].transform.localEulerAngles;
            hand.Joints[n].transform.localPosition = posL;
            hand.Joints[n].transform.localEulerAngles = eulL;
        }
    }

    public bool IsUsedForTraining(int n)
    {
        bool yn = false;
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            if (indexesTraining[i] == n)
            {
                yn = true;
                break;
            }
        }
        return yn;
    }

    void UpdateMarkers()
    {
        for (int i = 0; i < indexesTraining.Length; i++)
        {
            int n = indexesTraining[i];
            Vector3 pos = handLive.Joints[n].transform.position;
            Vector3 eul = handLive.Joints[n].transform.eulerAngles;
            markers[i].transform.position = pos;
            markers[i].transform.eulerAngles = eul;
        }
    }

    void CreateMarkers()
    {
        markerPrefab.SetActive(true);
        for (int n = 0; n < indexesTraining.Length; n++)
        {
            GameObject marker = Instantiate(markerPrefab, transform);
            marker.transform.localScale *= 2;
            markers.Add(marker);
        }
        markerPrefab.SetActive(false);
    }

    void UpdateRecord()
    {
        if (!ynRecord) return;
        if (!ynRecordStart) return;
        HandsLiveToData();
    }

    void HandsLiveToData()
    {
        List<float> dataRecord = new();
        float elapsed = Time.realtimeSinceStartup - timeRecordStart;
        dataRecord.Add(elapsed);
        HandVisual hand = null;
        for (int h = 0; h < 2; h++)
        {
            if (Application.isEditor)
            {
                if (h == 0) hand = handLeft;
                if (h == 0) xrRootLive = handLeft.gameObject;
                if (h == 1) hand = handRight;
                if (h == 1) xrRootLive = handRight.gameObject;
            } else
            {
                if (h == 0)
                {
                    hand = handLiveLeft;
                    xrRootLive = xrRootLiveLeft;
                }
                if (h == 1)
                {
                    hand = handLiveRight;
                    xrRootLive = xrRootLiveRight;
                }
            }
            for (int n = 0; n < hand.Joints.Count; n++)
            {
                Vector3 posL = hand.Joints[n].transform.localPosition;
                Vector3 eulL = hand.Joints[n].transform.localEulerAngles;
                dataRecord.Add(posL.x);
                dataRecord.Add(posL.y);
                dataRecord.Add(posL.z);
                dataRecord.Add(eulL.x);
                dataRecord.Add(eulL.y);
                dataRecord.Add(eulL.z);
            }
            GameObject parentOrig = xrRootLive.transform.parent.gameObject;
            xrRootLive.transform.SetParent(transform);
            Vector3 wristPosL = xrRootLive.transform.localPosition;
            Vector3 wristEulL = xrRootLive.transform.localEulerAngles;
            xrRootLive.transform.SetParent(parentOrig.transform);
            dataRecord.Add(wristPosL.x);
            dataRecord.Add(wristPosL.y);
            dataRecord.Add(wristPosL.z);
            dataRecord.Add(wristEulL.x);
            dataRecord.Add(wristEulL.y);
            dataRecord.Add(wristEulL.z);
        }
        dataHands.Add(dataRecord);
    }

    public void DataToHands(List<List<float>> data, int nRecord)
    {
        frameCurrent = nRecord;
        List<float> dataRecord = data[nRecord];
        HandVisual hand = null;
        for(int h = 0; h < 2; h++)
        {
            if (h == 0) hand = handLeft;
            if (h == 1) hand = handRight;
            int countJoints = hand.Joints.Count;
            for (int n = 0; n < countJoints; n++)
            {
                float xPosL = dataRecord[1 + (h * 162) + n * 6 + 0];
                float yPosL = dataRecord[1 + (h * 162) + n * 6 + 1];
                float zPosL = dataRecord[1 + (h * 162) + n * 6 + 2];
                Vector3 posL = new(xPosL, yPosL, zPosL);
                hand.Joints[n].transform.localPosition = posL;
                float xEulL = dataRecord[1 + (h * 162) + n * 6 + 3];
                float yEulL = dataRecord[1 + (h * 162) + n * 6 + 4];
                float zEulL = dataRecord[1 + (h * 162) + n * 6 + 5];
                Vector3 eulL = new(xEulL, yEulL, zEulL);
                hand.Joints[n].transform.localEulerAngles = eulL;
            }
            float xPos = dataRecord[1 + (h * 162) + countJoints * 6 + 0];
            float yPos = dataRecord[1 + (h * 162) + countJoints * 6 + 1];
            float zPos = dataRecord[1 + (h * 162) + countJoints * 6 + 2];
            Vector3 wristPosL = new(xPos, yPos, zPos);
            float xEul = dataRecord[1 + (h * 162) + countJoints * 6 + 3];
            float yEul = dataRecord[1 + (h * 162) + countJoints * 6 + 4];
            float zEul = dataRecord[1 + (h * 162) + countJoints * 6 + 5];
            Vector3 wristEulL = new(xEul, yEul, zEul);
            GameObject parentOrig = hand.transform.parent.gameObject;
            hand.transform.SetParent(transform);
            hand.transform.localPosition = wristPosL;
            hand.transform.localEulerAngles = wristEulL;
            hand.transform.SetParent(parentOrig.transform);
        }
    }

    public void LoadDataFromString(string txtAll)
    {
        StringToDataHands(txtAll);
        SetNumRecordsAndNumFields();
        SetDuration();
    }

    void StringToDataHands(string txtAll)
    {
        dataHands.Clear();
        string[] txtLines = txtAll.Split('\n');
        int nStart = 0;
        if (txtLines.Length > 0 && IsHeader(txtLines[0]))
        {
            nStart = 1;
        }
        for (int n = nStart; n < txtLines.Length; n++)
        {
            string[] txtRecord = txtLines[n].Split(',');
            List<float> dataRecord = new();
            for (int nn = 0; nn < txtRecord.Length; nn++)
            {
                float v = float.Parse(txtRecord[nn]);
                dataRecord.Add(v);
            }
            dataHands.Add(dataRecord);
        }
    }

    void SetNumRecordsAndNumFields()
    {
        numRecords = dataHands.Count;
        numFields = 0;
        if (dataHands.Count > 0)
        {
            numFields = dataHands[0].Count;
        }
    }

    void SetDuration()
    {
        duration = -1;
        if (numRecords == 0) return;
        if (numFields % 6 == 1)
        {
            duration = dataHands[numRecords - 1][0];
        }
    }

    public bool IsNumeric(string txt)
    {
        bool ynIsNumeric = false;
        if (float.TryParse(txt, out _))
        {
            ynIsNumeric = true;
        }
        return ynIsNumeric;
    }

    public float NormalizeAngle(float vv)
    {
        float v = vv;
        if (v < -180) v += 360;
        if (v > 180) v -= 360;
        return v;
    }

    bool IsHeader(string txtLine)
    {
        string txtFirst = txtLine.Split(',')[0];
        bool ynIsNumeric = IsNumeric(txtFirst);
        return !ynIsNumeric;
    }

    public void GamePressed()
    {
        rpsUI.PlayTick();
        rpsUI.ThrowPressed();  // game needs throws not gestures
        rpsUI.RockPressed();  // game needs rps gesture not screensaver
        ynGame = !ynGame;
        scoreDisplaysMgr.gameObject.SetActive(ynGame);
        scoreDisplaysMgr.ClearScores();        
        if (ynGame)
        {
            Debug.Log("GamePressed...\n");
            ynThrow = true;
            ynThrowRandom = true;
            scoreDisplaysMgr.ShowScoreDisplays();
            MorphThrowAndPlayback();
        }
        else
        {
            CancelInvoke(nameof(ScoreAndShow));
            ynThrow = false;
            ynThrowRandom = false;
        }
    }

    public void GesturePressed()
    {
        gestureThrowCurrent = GestureThrowType._gesture;
        fileMgr.LoadDataFromPersistentFile();
    }

    public void ThrowPressed()
    {
        gestureThrowCurrent = GestureThrowType._throw;
        fileMgr.LoadDataFromPersistentFile();
    }

    public void RockPressed()
    {
        gestureCurrent = GestureType.rock;
        fileMgr.LoadDataFromPersistentFile();
    }

    public void PaperPressed()
    {
        gestureCurrent = GestureType.paper;
        fileMgr.LoadDataFromPersistentFile();
    }

    public void ScissorsPressed()
    {
        gestureCurrent = GestureType.scissors;
        fileMgr.LoadDataFromPersistentFile();
    }

    public void ScreensaverPressed()
    {
        gestureCurrent = GestureType.screensaver;
        fileMgr.LoadDataFromPersistentFile();
    }

    public void RecordPressed()
    {
        ynRecord = !ynRecord;
        if (ynRecord)
        {
            RecordStart();
        }
        else
        {
            RecordStop();
        }
    }

    void RecordStart()
    {
        dataHands.Clear();
        ynRecord = true;
        ynRecordStart = true;
        timeRecordStart = Time.realtimeSinceStartup;
        rpsUI.HighlightButton(rpsUI.quadRecord, ynRecordStart);
        Invoke(nameof(RecordStopAndSave), durationRecord);
        HideHandsIfRecording();
    }

    void RecordStop()
    {
        CancelInvoke(nameof(RecordStopAndSave));
        ynRecord = false;
        ynRecordStart = false;
        if (rpsUI) rpsUI.RecordStop();
        HideHandsIfRecording();
    }

    void RecordStopAndSave()
    {
        RecordStop();
        fileMgr.SaveDataToPersistentFile();
    }

    void HideHandsIfRecording()
    {
        handLeft.gameObject.SetActive(!ynRecord);
        handRight.gameObject.SetActive(!ynRecord);
    }

    string GetHeader()
    {
        string s = ",";
        string txtLine = "0:elapsed";
        int nTrain = 0;
        for(int n = 0; n < handLeft.Joints.Count * 6; n++)
        {
            int j = n / 6;
            string txt = (n + 1) + ":" + j + ":";
            int d = n % 6;
            if (d == 0) txt += "xPos";
            if (d == 1) txt += "yPos";
            if (d == 2) txt += "zPos";
            if (d == 3) txt += "xEul"; // tracked for training
            if (d == 4) txt += "yEul";
            if (d == 5) txt += "zEul";
            if (IsUsedForTraining(j) && d == 3)
            {
                txt = "TRAIN:" + nTrain + "(" + txt + ")";
                nTrain++;
            }
            txtLine += s + txt;
        }
        txtLine += s + "xPos(Wrist)";
        txtLine += s + "yPos(Wrist)";
        txtLine += s + "zPos(Wrist)";
        txtLine += s + "xEul(Wrist)";
        txtLine += s + "yEul(Wrist)";
        txtLine += s + "zEul(Wrist)";
        return txtLine;
    }

    public string DataHandsToString()
    {
        string txtLines = GetHeader();
        string s = "\n";
        for (int n = 0; n < dataHands.Count; n++)
        {
            List<float> dataRecord = dataHands[n];
            string txtLine = "";
            string ss = "";
            for (int nn = 0; nn < dataRecord.Count; nn++)
            {
                float v = dataRecord[nn];
                if ((nn + 1) % 6 > 2)
                {
                    v = NormalizeAngle(v);
                }
                txtLine += ss + v;
                ss = ",";
            }
            txtLines += s + txtLine;
        }
        return txtLines;
    }

    string GetTrainingHeader()
    {
        string txtLine = "";
        string s = "";
        for(int n = 0; n < indexesTraining.Length; n++)
        {
            string txt = "joint:" + n + "(eulX)";
            txtLine += s + txt;
            s = ",";
        }
        txtLine += s + "class rps (0-3)";
        return txtLine;
    }

    public string GetTrainingData()
    {
        string txtLines = GetTrainingHeader();
        GestureType gestureLast = gestureCurrent;
        GestureThrowType gestureThrowLast = gestureThrowCurrent;
        gestureThrowCurrent = GestureThrowType._gesture;
        string s = "\n";
        for(int n = 0; n < 3; n++)
        {
            if (n == 0) gestureCurrent = GestureType.rock;
            if (n == 1) gestureCurrent = GestureType.paper;
            if (n == 2) gestureCurrent = GestureType.scissors;
            fileMgr.LoadDataFromPersistentFile();
            for(int nRecord = 0; nRecord < dataHands.Count; nRecord++)
            {
                string txtLine = "";
                string ss = "";
                for(int i = 0; i < indexesTraining.Length; i++)
                {
                    int j = indexesTraining[i];
                    float eulX = dataHands[nRecord][1 + j * 6 + 3];
                    eulX = NormalizeAngle(eulX);
                    txtLine += ss + eulX;
                    ss = ",";
                }
                txtLine += ss + n;
                txtLines += s + txtLine;
            }
        }
        gestureCurrent = gestureLast;
        gestureThrowCurrent = gestureThrowLast;
        fileMgr.LoadDataFromPersistentFile();
        return txtLines;
    }

    public void PlaybackStart()
    {
        ynPlayback = true;
        fileMgr.LoadDataFromPersistentFile();
        timePlaybackStart = Time.realtimeSinceStartup;
    }

    public void PlaybackStop()
    {
        ynPlayback = false;
    }

    public void SetCurrentParameters(GestureType gesture, GestureThrowType gestureThrow)
    {
        if (gesture == GestureType.rock) gestureCurrent = GestureType.rock;
        if (gesture == GestureType.paper) gestureCurrent = GestureType.paper;
        if (gesture == GestureType.scissors) gestureCurrent = GestureType.scissors;
        if (gesture == GestureType.screensaver) gestureCurrent = GestureType.screensaver;
        if (gestureThrow == GestureThrowType._gesture) gestureThrowCurrent = GestureThrowType._gesture;
        if (gestureThrow == GestureThrowType._throw) gestureThrowCurrent = GestureThrowType._throw;
    }

    public void LoadDataHandsScreensaver()
    {
        GestureType gestureLast = gestureCurrent;
        GestureThrowType gestureThrowLast = gestureThrowCurrent;
        gestureCurrent = GestureType.screensaver;
        gestureThrowCurrent = GestureThrowType._throw;
        fileMgr.LoadDataFromPersistentFile();
        dataHandsScreensaver = new List<List<float>>(dataHands);
        gestureCurrent = gestureLast;
        gestureThrowCurrent = gestureThrowLast;
    }

    public void LoadRepresentativeInputsRPS()
    {
        gestureThrowCurrent = GestureThrowType._gesture;
        gestureCurrent = GestureType.rock;
        fileMgr.LoadDataFromPersistentFile();
        representativeInputsRock = GetAverageInputs();
        gestureCurrent = GestureType.paper;
        fileMgr.LoadDataFromPersistentFile();
        representativeInputsPaper = GetAverageInputs();
        gestureCurrent = GestureType.scissors;
        fileMgr.LoadDataFromPersistentFile();
        representativeInputsScissors = GetAverageInputs();
    }

}
public enum GestureType
{
    rock,
    paper,
    scissors,
    screensaver
}
public enum GestureThrowType
{
    _gesture,
    _throw
}
public enum LeftRightType
{
    left,
    right
}
