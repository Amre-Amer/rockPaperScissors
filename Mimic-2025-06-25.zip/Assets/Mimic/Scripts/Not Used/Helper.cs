using UnityEngine;

public class Helper : MonoBehaviour
{
    //public HandXRRecordMgr handXRRecordMgr;
    int cntFrames;

    //private void Awake()
    //{
    //    handXRRecordMgr.gameObject.SetActive(false);  // needed for some reason, avoids camera sinking down forever !
    //}

    //void Update()
    //{
    //    if (cntFrames == 1) handXRRecordMgr.gameObject.SetActive(true); // needed for some reason, avoids camera sinking down forever !
    //    cntFrames++;
    //}
}
