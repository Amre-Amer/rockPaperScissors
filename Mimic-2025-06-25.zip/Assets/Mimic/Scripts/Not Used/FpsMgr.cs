using UnityEngine;
using TMPro;

public class FpsMgr : MonoBehaviour
{
    public TMP_Text textFps;
    int cntFps;

    void Start()
    {
        InvokeRepeating(nameof(Fps), 1, 1);
    }

    void Update()
    {
        cntFps++;
    }

    void Fps()
    {
        textFps.text = "fps: " + cntFps;
        cntFps = 0;
    }
}
