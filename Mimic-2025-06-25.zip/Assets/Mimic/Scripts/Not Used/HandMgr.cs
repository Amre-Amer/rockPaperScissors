using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class HandMgr : MonoBehaviour
{
    public TextAsset textAsset;
    string txtData;
    public OVRSkeleton hand;
    HandMgr handMgr;
    public List<float[]> data = new List<float[]>();
    public List<float[]> dataSource = new List<float[]>();
    public List<float[]> dataTarget = new List<float[]>();
    public bool ynLoop;
    public int frameCurrent;
    Vector3 wristLocalPosition;
    Vector3 wristLocalEulers;
    bool ynLoopOnce;
    float timeStart;
    float speed = 1;
    public bool ynWristMotion;
    int[] indexesTraining = new int[] { 7, 12, 17, 22 };
    public bool ynShowTrainingOnly;
    float[] averageInputs;
    float[] middleInputs;
    public bool ynMorph;
    public float morphDuration = .5f;
    public float morphStartTime;
    OVRSkeleton handMorph;
    public int nRecordSource;
    public int nRecordTarget;
    public Material matHand;
    public float duration;
    public int numRecords;
    public int numFields;
    public bool ynMorphEndoToStartOfAnotherAfterLoopOnce;
    public HandMgr handMorphToStart;
    HandMgr handMorphSource;
    HandMgr handMorphTarget;
    public float morphFraction;
    SkinnedMeshRenderer skinnedMeshRenderer;

    private void Awake()
    {
        handMgr = hand.GetComponent<HandMgr>();
        skinnedMeshRenderer = GetComponentInChildren<SkinnedMeshRenderer>();
        if (textAsset)
        {
            txtData = textAsset.text;
            LoadTxtDataToData();
            SetAverageInputs();
            SetMiddleInputs();
            //LoadRecordLast();
            //LoadRecordFirst();
        }
    }

    void Update()
    {
        UpdateLoop();
        UpdateMorph();
    }

    void UpdateLoop()
    {
        if (!ynLoop) return;
        bool ynFound = false;
        float timeTarget = Time.realtimeSinceStartup - timeStart;
        timeTarget *= speed;
        for (int nLine = 0; nLine < data.Count; nLine++)
        {
            float[] dataLine = data[nLine];
            float elapsed = dataLine[0];
            if (timeTarget < elapsed)
            {
                DataToHand(hand, nLine);
                ynFound = true;
                break;
            }
        }
        if (!ynFound)
        {
            if (ynLoopOnce)
            {
                ynLoopOnce = false;
                ynLoop = false;
                ynMorphEndoToStartOfAnotherAfterLoopOnce = false;
                if (ynMorphEndoToStartOfAnotherAfterLoopOnce)
                {
                    if (handMorph)
                    {
                        ynMorph = true;
                        morphStartTime = Time.realtimeSinceStartup;
                        handMorphSource = hand.GetComponent<HandMgr>();
                        dataSource = handMorphSource.data;
                        handMorphTarget = handMorphToStart.GetComponent<HandMgr>();
                        dataTarget = handMorphTarget.data;
                        handMorph = hand;
                        nRecordSource = dataSource.Count - 1;
                        nRecordTarget = 0;
                    }
                }
                return;
            }
            ynLoop = false;
            Invoke(nameof(RestartLoop), morphDuration);
            //MorphStartEndToStart();
        }
    }

    void MorphStartEndToStart()
    {
        ynMorph = true;
        handMorphSource = handMgr;
        handMorphTarget = handMgr;
        morphStartTime = Time.realtimeSinceStartup;
        dataSource = handMorphSource.data;
        dataTarget = handMorphTarget.data;
        handMorph = hand;
        nRecordSource = dataSource.Count - 1;
        nRecordTarget = 0;
        Debug.Log("data.Count:" + data + "\n");
        Debug.Log("dataSource.Count:" + dataSource.Count + "\n");
    }

    public void StartMorphEndToStart(HandMgr handSource, HandMgr handTarget, int nRecordSource0, int nRecordTarget0, float morphDuration0)
    {
        ynMorph = true;
        morphDuration = morphDuration0;
        morphStartTime = Time.realtimeSinceStartup;
        handMorphSource = handSource;
        handMorphTarget = handTarget;
        dataSource = handMorphSource.data;
        dataTarget = handMorphTarget.data;
        handMorph = handTarget.GetComponent<OVRSkeleton>();
        nRecordSource = nRecordSource0;
        nRecordTarget = nRecordTarget0;
        //nRecordSource = dataSource.Count - 1;
        //nRecordTarget = 0;
    }

    void RestartLoop()
    {
        timeStart = Time.realtimeSinceStartup;
        ynLoop = true;
    }

    void UpdateMorph()
    {
        if (!ynMorph) return;
        float elapsed = Time.realtimeSinceStartup - morphStartTime;
        if (elapsed >= morphDuration)
        {
            ynMorph = false;
            return;
        }
        morphFraction = elapsed / morphDuration;
        int count;
        count = handMorph.Bones.Count;
        for (int n = 0; n < count; n++)
        {
            dataSource = data;
            dataTarget = data;
            float eulX = dataSource[nRecordSource][1 + n * 3 + 0];
            float eulY = dataSource[nRecordSource][1 + n * 3 + 1];
            float eulZ = dataSource[nRecordSource][1 + n * 3 + 2];
            Vector3 eul = new Vector3(eulX, eulY, eulZ);
            Quaternion sourceRotation = Quaternion.Euler(eul);
            eulX = dataTarget[nRecordTarget][1 + n * 3 + 0];
            eulY = dataTarget[nRecordTarget][1 + n * 3 + 1];
            eulZ = dataTarget[nRecordTarget][1 + n * 3 + 2];
            eul = new Vector3(eulX, eulY, eulZ);
            Quaternion targetRotation = Quaternion.Euler(eul);
            Quaternion interpolatedRotation = Quaternion.Slerp(sourceRotation, targetRotation, morphFraction);
            handMorph.Bones[n].Transform.localRotation = interpolatedRotation;
        }
    }

    public void SetFrameToFirst()
    {
        int nRecord = 0;
        DataToHand(hand, nRecord);
    }

    public void SetFrameToLast()
    {
        int nRecord = hand.Bones.Count - 1;
        DataToHand(hand, nRecord);
    }

    public void HighlightHandWithMat(Material mat)
    {
        skinnedMeshRenderer.enabled = true;
        skinnedMeshRenderer.material = mat;
    }

    public void HighlightHandOff()
    {
        skinnedMeshRenderer.enabled = true;
        skinnedMeshRenderer.material = matHand;
    }

    void SetMiddleInputs()
    {
        string filename = textAsset.name + "_middle.csv";
        string filespec = Path.Combine(Application.persistentDataPath, filename);
        string txtLines = "";
        int nRecordMiddle = data.Count / 2;
        middleInputs = new float[indexesTraining.Length];
        for (int n = 0; n < indexesTraining.Length; n++)
        {
            int nField = indexesTraining[n];
            int j = 1 + nField * 3;
            float v = data[nRecordMiddle][j];
            middleInputs[n] = v;
            string txtLine = n + "," + nField + "," + j + "," + v.ToString("F2") + "\n";
            txtLines += txtLine;
        }
        //File.WriteAllText(filespec, txtLines);
    }

    void SetAverageInputs()
    {
        string filename = textAsset.name + "_average.csv";
        string filespec = Path.Combine(Application.persistentDataPath, filename);
        string txtLines = "";
        averageInputs = new float[indexesTraining.Length];
        for (int n = 0; n < indexesTraining.Length; n++)
        {
            int nField = indexesTraining[n];
            int j = 1 + nField * 3;
            for (int nRecord = 0; nRecord < data.Count; nRecord++)
            {
                float v = data[nRecord][j];
                averageInputs[n] += v;
            }
        }
        for (int n = 0; n < indexesTraining.Length; n++)
        {
            averageInputs[n] /= data.Count;
            float v = averageInputs[n];
            int nField = indexesTraining[n];
            int j = 1 + nField * 3;
            string txtLine = n + "," + nField + "," + j + "," + v.ToString("F2") + "\n";
            txtLines += txtLine;
        }
        //File.WriteAllText(filespec, txtLines);
    }

    public float[] GetAverageInputs()
    {
        return averageInputs;
    }

    public float[] GetMiddleInputs()
    {
        return middleInputs;
    }

    void ShowAverage()
    {
        int nRecordMiddle = (int)(data.Count / 2f);
        float[] dataFields = new float[data[nRecordMiddle].Length];
        for (int na = 0; na < averageInputs.Length; na++)
        {
            int nInput = indexesTraining[na];
            int nX = 1 + nInput * 3;
            dataFields[nX] = averageInputs[na];
        }
        data[nRecordMiddle] = dataFields;
        DataToHand(hand, nRecordMiddle);
    }

    public void DataToHand(OVRSkeleton hand, int nRecord)
    {
        if (hand.Bones.Count == 0) return;
        frameCurrent = nRecord;
        float[] dataRecord = data[nRecord];
        int countVectors = (dataRecord.Length - 1) / 3;
        countVectors -= 2;
        for (int n = 0; n < countVectors; n++)
        {
            float x = dataRecord[1 + n * 3 + 0];
            float y = dataRecord[1 + n * 3 + 1];
            float z = dataRecord[1 + n * 3 + 2];
            Vector3 eul = new Vector3(x, y, z);
            if ((ynShowTrainingOnly && IsUsedForTraining(n)) || !ynShowTrainingOnly)
            {
                hand.Bones[n].Transform.localEulerAngles = eul;
            }
        }
        float xPos = dataRecord[1 + countVectors * 3 + 0];
        float yPos = dataRecord[1 + countVectors * 3 + 1];
        float zPos = dataRecord[1 + countVectors * 3 + 2];
        wristLocalPosition = new Vector3(xPos, yPos, zPos);
        float xEul = dataRecord[1 + (countVectors + 1) * 3 + 0];
        float yEul = dataRecord[1 + (countVectors + 1) * 3 + 1];
        float zEul = dataRecord[1 + (countVectors + 1) * 3 + 2];
        wristLocalEulers = new Vector3(xEul, yEul, zEul);
        HandLiveWristToHandWrist(hand);
    }

    public bool IsUsedForTraining(int n)
    {
        bool yn = false;
        for(int i = 0; i < indexesTraining.Length; i++)
        {
            if (indexesTraining[i] == n)
            {
                yn = true;
                break;
            }
        }
        return yn;
    }

    public void StartLoopTrain()
    {
        ynLoop = true;
        ynLoopOnce = false;
        ynShowTrainingOnly = true;
        timeStart = Time.realtimeSinceStartup;
    }

    public void LoadRecordFirst()
    {
        int n = 0;
        DataToHand(hand, n);
    }

    public void LoadRecordLast() {
        int n = data.Count - 1;
        DataToHand(hand, n);
    }

    public void StartLoop()
    {
        ynLoop = true;
        ynLoopOnce = false;
        ynShowTrainingOnly = false;
        timeStart = Time.realtimeSinceStartup;
    }

    public void StartLoopOnce()
    {
        ynLoop = true;
        ynLoopOnce = true;
        ynShowTrainingOnly = false;
        timeStart = Time.realtimeSinceStartup;
    }

    public void Pause()
    {
        ynLoop = false;
        ynLoopOnce = false;
        ynShowTrainingOnly = false;
    }

    public void SetSpeed(float s)
    {
        speed = s;
    }

    void HandLiveWristToHandWrist(OVRSkeleton hand)
    {
        if (!ynWristMotion) return;
        hand.transform.localPosition = wristLocalPosition;
        hand.transform.localEulerAngles = wristLocalEulers;
    }

    bool IsHeader(string txtLine)
    {
        string txtFirst = txtLine.Split(',')[0];
        bool ynIsNumeric = IsNumeric(txtFirst);
        return !ynIsNumeric;
    }

    public bool IsNumeric(string txt)
    {
        bool ynIsNumeric = false;
        if (float.TryParse(txt, out _))
        {
            ynIsNumeric = true;
        }
        return ynIsNumeric;
    }

    void LoadTxtDataToData()
    {
        data.Clear();
        string[] txtLines = txtData.Split('\n');
        int nStart = 0;
        if (txtLines.Length > 0)
        {
            if (IsHeader(txtLines[0]))
            {
                nStart = 1;
            }
        }
        for (int n = nStart; n < txtLines.Length; n++)
        {
            string txtLine = txtLines[n];
            string[] stuff = txtLine.Split(',');
            float[] dataRecord = new float[stuff.Length];
            for (int nn = 0; nn < stuff.Length; nn++)
            {
                float v = float.Parse(stuff[nn]);
                v =NormalizeAngle(v);
                dataRecord[nn] = v;
            }
            data.Add(dataRecord);
        }
        SetNumRecordsAndNumFields();
        SetDuration();
    }

    void SetNumRecordsAndNumFields()
    {
        numRecords = data.Count;
        numFields = 0;
        if (data.Count > 0)
        {
            numFields = data[0].Length;
        }
    }

    void SetDuration()
    {
        duration = -1;
        if (numRecords == 0) return;
        if (numFields % 3 == 1)
        {
            duration = data[numRecords - 1][0];
        }
    }

    public float NormalizeAngle(float vv)
    {
        float v = vv;
        if (v < -180) v += 360;
        if (v > 180) v -= 360;
        return v;
    }

    public void ResetHandMaterial()
    {
        SetMaterial(matHand);
    }

    public void SetMaterial(Material mat)
    {
        skinnedMeshRenderer.enabled = true;
        skinnedMeshRenderer.material = mat;
        //hand.GetComponentInChildren<MaterialPropertyBlockEditor>().Renderers[0].material = mat;
        //matEditor.Renderers[0].material = matHand;
        //matEditor.Renderers[0].material = mat;
    }
}
