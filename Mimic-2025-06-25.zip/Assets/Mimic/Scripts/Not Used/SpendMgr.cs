using System.Collections.Generic;
using UnityEngine;

public class SpendMgr : MonoBehaviour
{
    public TextAsset textAssetSpend;
    public GameObject barPrefab;
    List<List<float>> data = new List<List<float>>();

    void Start()
    {
        LoadSpend();
    }

    void LoadSpend() {
        data.Clear();
        float yLast = 0;
        string txtAll = textAssetSpend.text;
        txtAll = txtAll.TrimEnd('\n');
        string[] records = txtAll.Split('\n');
        for(int n = 0; n < records.Length; n++)
        {
            List<float> dataRecord = new List<float>();
            string[] fields = records[n].Split(',');
            Debug.Log("line:" + records[n] + "\n");
            for(int nn = 0; nn < fields.Length; nn++)
            {
                float day = float.Parse(fields[0]);
                float amt = float.Parse(fields[2]);
                dataRecord.Add(day);
                dataRecord.Add(amt);
                Debug.Log(n + ":" + day + ":" + (amt-yLast) + '\n');
                yLast = amt;
                amt /= 1000;
                float z = 0;
                GameObject bar = Instantiate(barPrefab, transform);
                bar.transform.position = new Vector3(day, amt/2, z);
                bar.transform.localScale = new Vector3(1, amt, 1);
            }
            data.Add(dataRecord);
        }
        float days = data[-1][0] - data[0][0];
        Debug.Log("days:" + days + "\n");
        float amtSpent = data[-1][1] - data[0][1];
        Debug.Log("amtSpent:" + amtSpent + "\n");
        float amtSpentPerDay = amtSpent / days;
        Debug.Log("amtSpentPerDay:" + amtSpentPerDay.ToString("F2") + "\n");
        float amtSpentPerMonth = amtSpentPerDay * 30;
        Debug.Log("amtSpentPerMonth:" + amtSpentPerMonth.ToString("F0") + "\n");
    }
}
